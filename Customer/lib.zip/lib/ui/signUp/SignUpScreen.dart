import 'dart:io';

import 'package:easy_localization/easy_localization.dart' as easyLocal;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

import 'package:foodie_customer/constants.dart';
import 'package:foodie_customer/main.dart';
import 'package:foodie_customer/model/User.dart';
import 'package:foodie_customer/services/FirebaseHelper.dart';
import 'package:foodie_customer/services/helper.dart';
import 'package:foodie_customer/ui/container/ContainerScreen.dart';
import 'package:foodie_customer/ui/location_permission_screen.dart';
import 'package:foodie_customer/ui/phoneAuth/PhoneNumberInputScreen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

File? _image;

class SignUpScreen extends StatefulWidget {
  @override
  State createState() => _SignUpState();
}

class _SignUpState extends State<SignUpScreen> {
  bool _obscureText = true; // To control password visibility
  bool _obscureTextConfirm = true;

  // void _togglePasswordVisibility() {
  //   setState(() {
  //     _obscureText = !_obscureText;
  //     _obscureTextConfirm = !_obscureTextConfirm;

  //   });
  // }

  final ImagePicker _imagePicker = ImagePicker();

  TextEditingController _passwordController = TextEditingController();

  GlobalKey<FormState> _key = GlobalKey();

  String? firstName;
  String? lastName;
  String? email;
  String? mobile;
  String? password;
  String? confirmPassword;
  String? referralCode;

  AutovalidateMode _validate = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) {
      retrieveLostData();
    }

    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        iconTheme: IconThemeData(
            color: isDarkMode(context) ? Colors.white : Colors.black),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: formUI(),
          ),
        ),
      ),
    );
  }

  Future<void> retrieveLostData() async {
    final LostDataResponse? response = await _imagePicker.retrieveLostData();

    if (response == null) {
      return;
    }

    if (response.file != null) {
      setState(() {
        _image = File(response.file!.path);
      });
    }
  }

  _onCameraClick() {
    final action = CupertinoActionSheet(
      message: Text(
        'Add profile picture',
        style: TextStyle(fontSize: 15.0),
      ).tr(),
      actions: <Widget>[
        CupertinoActionSheetAction(
          child: Text('Choose from gallery').tr(),
          isDefaultAction: false,
          onPressed: () async {
            Navigator.pop(context);

            XFile? image =
                await _imagePicker.pickImage(source: ImageSource.gallery);

            if (image != null)
              setState(() {
                _image = File(image.path);
              });
          },
        ),
        CupertinoActionSheetAction(
          child: Text('Take a picture').tr(),
          isDestructiveAction: false,
          onPressed: () async {
            Navigator.pop(context);

            XFile? image =
                await _imagePicker.pickImage(source: ImageSource.camera);

            if (image != null)
              setState(() {
                _image = File(image.path);
              });
          },
        )
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text('cancel').tr(),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );

    showCupertinoModalPopup(context: context, builder: (context) => action);
  }

  Widget formUI() {
    return Column(
      children: <Widget>[
        Align(
            alignment: Directionality.of(context) == TextDirection.ltr
                ? Alignment.topLeft
                : Alignment.topRight,
            child: Text(
              'Create new account',
              style: TextStyle(
                  color: Color(COLOR_PRIMARY),
                  fontWeight: FontWeight.bold,
                  fontSize: 25.0),
            ).tr()),

        Padding(
          padding:
              const EdgeInsets.only(left: 8.0, top: 32, right: 8, bottom: 8),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: <Widget>[
              CircleAvatar(
                radius: 65,
                backgroundColor: Colors.grey.shade400,
                child: ClipOval(
                  child: SizedBox(
                    width: 170,
                    height: 170,
                    child: _image == null
                        ? Image.asset(
                            'assets/images/placeholder.jpg',
                            fit: BoxFit.cover,
                          )
                        : Image.file(
                            _image!,
                            fit: BoxFit.cover,
                          ),
                  ),
                ),
              ),
              Positioned(
                left: 80,
                right: 0,
                child: FloatingActionButton(
                    backgroundColor: Color(COLOR_ACCENT),
                    child: Icon(
                      CupertinoIcons.camera,
                      color: isDarkMode(context) ? Colors.black : Colors.white,
                    ),
                    mini: true,
                    onPressed: _onCameraClick),
              )
            ],
          ),
        ),

        ConstrainedBox(
          constraints: BoxConstraints(minWidth: double.infinity),
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
            child: TextFormField(
              cursorColor: Color(COLOR_PRIMARY),
              textAlignVertical: TextAlignVertical.center,
              validator: validateName,
              onSaved: (String? val) {
                firstName = val;
              },
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                fillColor: Colors.white,
                hintText: easyLocal.tr('First Name'),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    borderSide:
                        BorderSide(color: Color(COLOR_PRIMARY), width: 2.0)),
                errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
            ),
          ),
        ),

        ConstrainedBox(
          constraints: BoxConstraints(minWidth: double.infinity),
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
            child: TextFormField(
              validator: validateName,
              textAlignVertical: TextAlignVertical.center,
              cursorColor: Color(COLOR_PRIMARY),
              onSaved: (String? val) {
                lastName = val;
              },
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                fillColor: Colors.white,
                hintText: 'Last Name'.tr(),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    borderSide:
                        BorderSide(color: Color(COLOR_PRIMARY), width: 2.0)),
                errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
            ),
          ),
        ),

        ConstrainedBox(
          constraints: BoxConstraints(minWidth: double.infinity),
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
            child: TextFormField(
              keyboardType: TextInputType.emailAddress,
              textAlignVertical: TextAlignVertical.center,
              textInputAction: TextInputAction.next,
              cursorColor: Color(COLOR_PRIMARY),
              validator: validateEmail,
              onSaved: (String? val) {
                email = val;
              },
              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                fillColor: Colors.white,
                hintText: 'Email Address'.tr(),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    borderSide:
                        BorderSide(color: Color(COLOR_PRIMARY), width: 2.0)),
                errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
            ),
          ),
        ),

        /// user mobile text field, this is hidden in case of sign up with

        /// phone number

        Padding(
          padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              shape: BoxShape.rectangle,
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: InternationalPhoneNumberInput(
              onInputChanged: (PhoneNumber number) =>
                  mobile = number.phoneNumber,

              ignoreBlank: true,

              autoValidateMode: AutovalidateMode.onUserInteraction,

              inputDecoration: InputDecoration(
                hintText: 'Phone Number'.tr(),
                border: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
                isDense: true,
                errorBorder: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
              ),

              inputBorder: const OutlineInputBorder(
                borderSide: BorderSide.none,
              ),

              initialValue:
                  PhoneNumber(isoCode: 'PH'), // Set default to the Philippines

              selectorConfig: const SelectorConfig(
                selectorType: PhoneInputSelectorType.DIALOG,
              ),
            ),
          ),
        ),

        ConstrainedBox(
          constraints: BoxConstraints(minWidth: double.infinity),
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
            child: TextFormField(
              obscureText: _obscureText, // Use the visibility state variable

              textAlignVertical: TextAlignVertical.center,

              textInputAction: TextInputAction.next,

              controller: _passwordController,

              validator: validatePassword,

              onSaved: (String? val) {
                password = val;
              },

              style: TextStyle(fontSize: 18.0),

              cursorColor: Color(COLOR_PRIMARY),

              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                fillColor: Colors.white,
                hintText: 'Password'.tr(),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureText ? Icons.visibility_off : Icons.visibility,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscureText = !_obscureText; // Toggle visibility
                    });
                  },
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide:
                      BorderSide(color: Color(COLOR_PRIMARY), width: 2.0),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
            ),
          ),
        ),

        ConstrainedBox(
          constraints: BoxConstraints(minWidth: double.infinity),
          child: Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),
            child: TextFormField(
              textAlignVertical: TextAlignVertical.center,

              textInputAction: TextInputAction.done,

              onFieldSubmitted: (_) => _signUp(),

              obscureText:
                  _obscureTextConfirm, // Use the visibility state variable

              validator: (val) =>
                  validateConfirmPassword(_passwordController.text, val),

              onSaved: (String? val) {
                confirmPassword = val;
              },

              style: TextStyle(fontSize: 18.0),

              cursorColor: Color(COLOR_PRIMARY),

              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                fillColor: Colors.white,
                hintText: 'Confirm Password'.tr(),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureTextConfirm
                        ? Icons.visibility_off
                        : Icons.visibility,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscureTextConfirm =
                          !_obscureTextConfirm; // Toggle visibility
                    });
                  },
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide:
                      BorderSide(color: Color(COLOR_PRIMARY), width: 2.0),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Theme.of(context).colorScheme.error),
                  borderRadius: BorderRadius.circular(25.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
            ),
          ),
        ),

        //ConstrainedBox(

        //  constraints: BoxConstraints(minWidth: double.infinity),

        //  child: Padding(

        //    padding: const EdgeInsets.only(top: 16.0, right: 8.0, left: 8.0),

        //    child: TextFormField(

        //      textAlignVertical: TextAlignVertical.center,

        //      textInputAction: TextInputAction.next,

        //      onSaved: (String? val) {

        //        referralCode = val;

        //      },

        //      style: TextStyle(fontSize: 18.0),

        //      cursorColor: Color(COLOR_PRIMARY),

        //      decoration: InputDecoration(

        //        contentPadding:

        //            EdgeInsets.symmetric(vertical: 8, horizontal: 16),

        //        fillColor: Colors.white,

        //        hintText: 'Referral Code (Optional)'.tr(),

        //        focusedBorder: OutlineInputBorder(

        //            borderRadius: BorderRadius.circular(25.0),

        //            borderSide:

        //                BorderSide(color: Color(COLOR_PRIMARY), width: 2.0)),

        //        errorBorder: OutlineInputBorder(

        //          borderSide:

        //              BorderSide(color: Theme.of(context).colorScheme.error),

        //          borderRadius: BorderRadius.circular(25.0),

        //        ),

        //        focusedErrorBorder: OutlineInputBorder(

        //          borderSide:

        //              BorderSide(color: Theme.of(context).colorScheme.error),

        //          borderRadius: BorderRadius.circular(25.0),

        //        ),

        //        enabledBorder: OutlineInputBorder(

        //          borderSide: BorderSide(color: Colors.grey.shade200),

        //          borderRadius: BorderRadius.circular(25.0),

        //        ),

        //      ),

        //    ),

        //  ),

        //),

        Padding(
          padding: const EdgeInsets.only(right: 40.0, left: 40.0, top: 40.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minWidth: double.infinity),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.only(top: 12, bottom: 12),
                backgroundColor: Color(COLOR_PRIMARY),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  side: BorderSide(
                    color: Color(COLOR_PRIMARY),
                  ),
                ),
              ),
              child: Text(
                'Sign Up'.tr(),
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode(context) ? Colors.black : Colors.white,
                ),
              ),
              onPressed: () => _signUp(),
            ),
          ),
        ),

        (!kIsWeb &&
                (defaultTargetPlatform == TargetPlatform.android ||
                    defaultTargetPlatform == TargetPlatform.iOS))
            ? Padding(
                padding: const EdgeInsets.all(32.0),
                child: Center(
                  child: Text(
                    'or',
                    style: TextStyle(
                        color:
                            isDarkMode(context) ? Colors.white : Colors.black),
                  ).tr(),
                ),
              )
            : Container(),

        (!kIsWeb &&
                (defaultTargetPlatform == TargetPlatform.android ||
                    defaultTargetPlatform == TargetPlatform.iOS))
            ? Padding(
                padding:
                    const EdgeInsets.only(right: 40.0, left: 40.0, bottom: 12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minWidth: double.infinity),
                  child: ElevatedButton.icon(
                    label: Container(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Sign Up with Google'.tr(),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87),
                        )),
                    icon: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 12),
                      child: Icon(
                        Icons.g_mobiledata,
                        size: 28,
                        color: Colors.black87,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25.0),
                        side: BorderSide(
                          color: Colors.grey.shade300,
                        ),
                      ),
                    ),
                    onPressed: () => _signUpWithGoogle(),
                  ),
                ),
              )
            : Container(),

        InkWell(
          onTap: () {
            push(context, PhoneNumberInputScreen(login: false));
          },
          child: Padding(
            padding: EdgeInsets.only(top: 10, right: 40, left: 40, bottom: 24),
            child: Container(
              alignment: Alignment.bottomCenter,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(color: Color(COLOR_PRIMARY), width: 1)),
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(
                  Icons.phone,
                  color: Color(COLOR_PRIMARY),
                ),
                SizedBox(width: 8),
                Flexible(
                  child: Text(
                    "Sign Up With Phone Number".tr(),
                    style: TextStyle(
                        color: Color(COLOR_PRIMARY),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        letterSpacing: 1),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ]),
            ),
          ),
        ),

        //Padding(

        //  padding: const EdgeInsets.all(32.0),

        //  child: Center(

        //    child: Text(

        //      'or',

        //      style: TextStyle(

        //          color: isDarkMode(context) ? Colors.white : Colors.black),

        //    ).tr(),

        //  ),

        //),

        //InkWell(

        //  onTap: () {

        //    push(context, PhoneNumberInputScreen(login: false));

        //  },

        //  child: Padding(

        //    padding: EdgeInsets.only(top: 10, right: 40, left: 40),

        //    child: Container(

        //      alignment: Alignment.bottomCenter,

        //      padding: EdgeInsets.all(5),

        //      decoration: BoxDecoration(

        //          borderRadius: BorderRadius.circular(25),

        //          border: Border.all(color: Color(COLOR_PRIMARY), width: 1)),

        //      child: Row(

        //        mainAxisAlignment: MainAxisAlignment.spaceEvenly,

        //        children: [

        //          Icon(

        //            Icons.phone,

        //            color: Color(COLOR_PRIMARY),

        //          ),

        //          Flexible(

        //            // Allow Text to shrink if needed

        //            child: Text(

        //              "Sign Up With Phone Number".tr(),

        //              style: TextStyle(

        //                  color: Color(COLOR_PRIMARY),

        //                  fontWeight: FontWeight.bold,

        //                  letterSpacing: 1),

        //              overflow: TextOverflow.ellipsis, // Prevent overflow

        //            ),

        //          ),

        //        ],

        //      ),

        //    ),

        //  ),

        //)
      ],
    );
  }

  /// dispose text controllers to avoid memory leaks

  @override
  void dispose() {
    _passwordController.dispose();

    _image = null;

    super.dispose();
  }

  /// if the fields are validated and location is enabled we create a new user

  /// and navigate to [ContainerScreen] else we show error

  _signUp() async {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState!.save();

      // Check for duplicate phone number before proceeding
      final bool phoneExists = await _isPhoneNumberTaken(mobile?.trim());
      if (phoneExists) {
        showAlertDialog(context, 'error'.tr(),
            'This phone number is already in use.'.tr(), true);
        return;
      }

      await _signUpWithEmailAndPassword();
    } else {
      setState(() {
        _validate = AutovalidateMode.onUserInteraction;
      });
    }
  }

  Future<bool> _isPhoneNumberTaken(String? phone) async {
    if (phone == null || phone.isEmpty) return false;
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection(USERS)
          .where('phoneNumber', isEqualTo: phone)
          .limit(1)
          .get();
      return querySnapshot.docs.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  _signUpWithEmailAndPassword() async {
    await showProgress(
        context, "Creating new account, Please wait...".tr(), false);

    dynamic result = await FireStoreUtils.firebaseSignUpWithEmailAndPassword(
        email!.trim(),
        password!.trim(),
        _image,
        firstName!,
        lastName!,
        mobile!,
        context,
        referralCode.toString());

    await hideProgress();

    if (result != null && result is User) {
      MyAppState.currentUser = result;

      if (MyAppState.currentUser!.shippingAddress != null &&
          MyAppState.currentUser!.shippingAddress!.isNotEmpty) {
        if (MyAppState.currentUser!.shippingAddress!
            .where((element) => element.isDefault == true)
            .isNotEmpty) {
          MyAppState.selectedPosotion = MyAppState.currentUser!.shippingAddress!
              .where((element) => element.isDefault == true)
              .single;
        } else {
          MyAppState.selectedPosotion =
              MyAppState.currentUser!.shippingAddress!.first;
        }

        pushAndRemoveUntil(context, ContainerScreen(user: result), false);
      } else {
        pushAndRemoveUntil(context, LocationPermissionScreen(), false);
      }
    } else if (result != null && result is String) {
      showAlertDialog(context, 'failed'.tr(), result, true);
    } else {
      showAlertDialog(context, 'failed'.tr(), "Couldn't sign up".tr(), true);
    }
  }

  _signUpWithGoogle() async {
    await showProgress(context, "Signing up, please wait...".tr(), false);
    bool hadError = false;
    dynamic result;
    try {
      result = await FireStoreUtils.loginWithGoogle();
    } catch (e, s) {
      hadError = true;
      print('_SignUpScreen._signUpWithGoogle $e $s');
    } finally {
      try {
        await hideProgress();
      } catch (_) {}
    }

    if (!mounted) return;

    if (hadError) {
      showAlertDialog(
          context, 'error'.tr(), "Couldn't sign up with google.".tr(), true);
      return;
    }

    if (result != null && result is User) {
      MyAppState.currentUser = result;

      if (MyAppState.currentUser!.active == true) {
        if (MyAppState.currentUser!.shippingAddress != null &&
            MyAppState.currentUser!.shippingAddress!.isNotEmpty) {
          if (MyAppState.currentUser!.shippingAddress!
              .where((element) => element.isDefault == true)
              .isNotEmpty) {
            MyAppState.selectedPosotion = MyAppState
                .currentUser!.shippingAddress!
                .where((element) => element.isDefault == true)
                .single;
          } else {
            MyAppState.selectedPosotion =
                MyAppState.currentUser!.shippingAddress!.first;
          }

          pushAndRemoveUntil(context, ContainerScreen(user: result), false);
        } else {
          pushAndRemoveUntil(context, LocationPermissionScreen(), false);
        }
      } else {
        showAlertDialog(
            context,
            "Your account has been disabled, Please contact to admin.".tr(),
            "",
            true);
      }
    } else if (result != null && result is String) {
      showAlertDialog(context, 'error'.tr(), result.tr(), true);
    } else {
      showAlertDialog(
          context, 'error'.tr(), "Couldn't sign up with google.".tr(), true);
    }
  }
}
