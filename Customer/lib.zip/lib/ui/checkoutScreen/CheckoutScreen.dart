import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:foodie_customer/constants.dart';
import 'package:foodie_customer/main.dart';
import 'package:foodie_customer/model/AddressModel.dart';
import 'package:foodie_customer/model/OrderModel.dart';
import 'package:foodie_customer/services/FirebaseHelper.dart';
import 'package:foodie_customer/services/helper.dart';
import 'package:foodie_customer/services/localDatabase.dart';
import 'package:foodie_customer/ui/placeOrderScreen/PlaceOrderScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../model/TaxModel.dart';

class CheckoutScreen extends StatefulWidget {
  final String paymentOption, paymentType;
  final double total;
  final double? discount;
  final String? couponCode;
  final String? couponId, notes;
  final List<CartProduct> products;
  final List<String>? extraAddons;
  final String? tipValue;
  final bool? takeAway;
  final String? deliveryCharge;
  final String? size;
  final bool isPaymentDone;
  final List<TaxModel>? taxModel;
  final Map<String, dynamic>? specialDiscountMap;
  final Timestamp? scheduleTime;
  final AddressModel? address;

  const CheckoutScreen(
      {Key? key,
      required this.isPaymentDone,
      required this.paymentOption,
      required this.paymentType,
      required this.total,
      this.discount,
      this.couponCode,
      this.couponId,
      this.notes,
      required this.products,
      this.extraAddons,
      this.tipValue,
      this.takeAway,
      this.deliveryCharge,
      this.taxModel,
      this.specialDiscountMap,
      this.size,
      this.scheduleTime,
      this.address})
      : super(key: key);

  @override
  _CheckoutScreenState createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final fireStoreUtils = FireStoreUtils();
  late Map<String, dynamic>? adminCommission;
  String? adminCommissionValue = "", addminCommissionType = "";
  bool? isEnableAdminCommission = false;
  bool isLoading = false; // Manage loading state

  @override
  void initState() {
    super.initState();
    placeAutoOrder();
    fireStoreUtils.getAdminCommission().then((value) {
      if (value != null) {
        setState(() {
          adminCommission = value;
          adminCommissionValue = adminCommission!["adminCommission"].toString();
          addminCommissionType =
              adminCommission!["adminCommissionType"].toString();
          isEnableAdminCommission = adminCommission!["isAdminCommission"];
        });
      }
    });
  }

  placeAutoOrder() {
    if (widget.isPaymentDone) {
      Future.delayed(Duration(seconds: 2), () {
        placeOrder();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          isDarkMode(context) ? Colors.grey.shade900 : Colors.grey.shade50,
      appBar: AppBar(),
      body: Stack(
        children: [
          // Main UI
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: Text(
                  'Checkout'.tr(),
                  style: TextStyle(
                      fontSize: 24,
                      color: isDarkMode(context)
                          ? Colors.grey.shade300
                          : Colors.grey.shade800,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    // Payment Details
                    Container(
                      color: isDarkMode(context) ? Colors.black : Colors.white,
                      child: ListTile(
                        leading: Text(
                          'Payment'.tr(),
                          style: TextStyle(
                              color: Color(COLOR_PRIMARY),
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                        ),
                        trailing: Text(
                          widget.paymentOption,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                    ),
                    Divider(height: 3),
                    // Delivery Address
                    Container(
                      color: isDarkMode(context) ? Colors.black : Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Deliver to'.tr(),
                              style: TextStyle(
                                  color: Color(COLOR_PRIMARY),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width / 2,
                              child: Text(
                                widget.address?.getFullAddress() ??
                                    'No address selected',
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 18),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Divider(height: 3),
                    // Total
                    Container(
                      color: isDarkMode(context) ? Colors.black : Colors.white,
                      child: ListTile(
                        leading: Text(
                          'Total'.tr(),
                          style: TextStyle(
                              color: Color(COLOR_PRIMARY),
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                        ),
                        trailing: Text(
                          amountShow(amount: widget.total.toString()),
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                    ),
                  ],
                  shrinkWrap: true,
                ),
              ),
              // Place Order Button
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.all(20),
                    backgroundColor: Color(COLOR_PRIMARY),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: (widget.isPaymentDone || isLoading)
                      ? null
                      : () {
                          placeOrder();
                        },
                  child: Text(
                    'PLACE ORDER'.tr(),
                    style: TextStyle(
                        color:
                            isDarkMode(context) ? Colors.black : Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
          // Loading Indicator
          if (isLoading)
            Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }

  Future<void> placeOrder() async {
    if (isLoading) return;
    setState(() {
      isLoading = true; // Show loading indicator
    });
    try {
      log("Step 1: Validating products list");
      if (widget.products.isEmpty || widget.products.first.vendorID.isEmpty) {
        throw Exception("Invalid or missing vendorID");
      }

      log("Step 2: Fetching vendor details");
      final vendorModel = await fireStoreUtils
          .getVendorByVendorID(widget.products.first.vendorID)
          .whenComplete(() => setPrefData());

      log("Vendor details fetched: ${vendorModel.toJson()}");

      if (widget.address == null) {
        throw Exception("Delivery address is null");
      }

      log("Delivery address: ${widget.address?.getFullAddress()}");

      OrderModel orderModel = OrderModel(
        address: widget.address,
        author: MyAppState.currentUser,
        authorID: MyAppState.currentUser?.userID ?? '',
        createdAt: Timestamp.now(),
        products: widget.products,
        status: ORDER_STATUS_PLACED,
        vendor: vendorModel,
        vendorID: widget.products.first.vendorID,
        discount: widget.discount,
        couponCode: widget.couponCode,
        couponId: widget.couponId,
        notes: widget.notes,
        taxModel: widget.taxModel,
        paymentMethod: widget.paymentType,
        specialDiscount: widget.specialDiscountMap,
        tipValue: widget.tipValue,
        adminCommission:
            (isEnableAdminCommission ?? false) ? adminCommissionValue : "0",
        adminCommissionType:
            (isEnableAdminCommission ?? false) ? addminCommissionType : "",
        deliveryCharge: widget.deliveryCharge,
        scheduleTime: widget.scheduleTime,
      );

      log("Placing order with Firestore...");
      OrderModel placedOrder = await fireStoreUtils.placeOrder(orderModel);
      log("Order placed successfully: ${placedOrder.id}");

      showModalBottomSheet(
        isScrollControlled: true,
        isDismissible: false,
        context: context,
        enableDrag: false,
        backgroundColor: Colors.transparent,
        builder: (context) => PlaceOrderScreen(orderModel: placedOrder),
      );
    } catch (e) {
      log("Error in placeOrder: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Failed to place order: $e".tr()),
        ),
      );
    } finally {
      setState(() {
        isLoading = false; // Hide loading indicator
      });
    }
  }

  Future<void> setPrefData() async {
    SharedPreferences sp = await SharedPreferences.getInstance();

    // Save any necessary data here
    sp.setString("musics_key", "");
    sp.setString("addsize", "");
    log("Preferences have been set.");
  }
}
