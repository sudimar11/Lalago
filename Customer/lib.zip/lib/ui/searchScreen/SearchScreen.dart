import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:foodie_customer/AppGlobal.dart';
import 'package:foodie_customer/constants.dart';
import 'package:foodie_customer/model/ProductModel.dart';
import 'package:foodie_customer/model/VendorModel.dart';
import 'package:foodie_customer/services/FirebaseHelper.dart';
import 'package:foodie_customer/services/helper.dart';
import 'package:foodie_customer/ui/productDetailsScreen/ProductDetailsScreen.dart';
import 'package:foodie_customer/ui/vendorProductsScreen/newVendorProductsScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  SearchScreenState createState() => SearchScreenState();
}

class SearchScreenState extends State<SearchScreen> {
  late List<VendorModel> vendorList = [];
  late List<VendorModel> vendorSearchList = [];

  late List<ProductModel> productList = [];
  late List<ProductModel> productSearchList = [];

  final FireStoreUtils fireStoreUtils = FireStoreUtils();
  final FocusNode _searchFocusNode = FocusNode(); // Add FocusNode
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Automatically focus on the search box
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _searchFocusNode.requestFocus();
    });

    fireStoreUtils.getVendors().then((value) {
      setState(() {
        vendorList = value;
      });
    });
    fireStoreUtils.getAllProducts().then((value) {
      setState(() {
        // only keep products that are published
        productList = value.where((p) => p.publish == true).toList();
      });
    });
  }

  void _saveSearchQuery(String query) async {
    if (query.isEmpty) return; // Skip saving if the query is empty

    // Initialize SharedPreferences
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Save the query with the key 'lastSearch'
    await prefs.setString('lastSearch', query);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(Icons.arrow_back)),
          actions: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 50, top: 10, right: 10, bottom: 10),
                child: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: TextFormField(
                    focusNode: _searchFocusNode, // Assign the FocusNode
                    controller: _searchController,
                    textInputAction: TextInputAction.next,
                    onChanged: (value) {
                      onSearchTextChanged(value);
                    },
                    decoration: InputDecoration(
                      hintText: 'Search menu, restaurant or etc...'.tr(),
                      contentPadding:
                          const EdgeInsets.only(left: 10, right: 10, top: 10),
                      hintStyle: const TextStyle(
                          color: Color(0XFF8A8989), fontFamily: 'Poppinsr'),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                              color: Color(COLOR_PRIMARY), width: 2.0)),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                            color: Theme.of(context).colorScheme.error),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                            color: Theme.of(context).colorScheme.error),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey.shade200),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Visibility(
                  visible: vendorSearchList.isNotEmpty,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Restaurant",
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: vendorSearchList.length,
                        itemBuilder: (context, index) {
                          return data(vendorSearchList[index]);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Visibility(
                  visible: productSearchList.isNotEmpty,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Foods".tr(),
                        style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: productSearchList.length,
                        itemBuilder: (context, index) {
                          return product(productSearchList[index]);
                        },
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ));
  }

  void onSearchTextChanged(String text) {
    _saveSearchQuery(text); // Save the search query to SharedPreferences

    if (text.isEmpty) {
      setState(() {}); // Clear search results if the input is empty
      return;
    }

    // Filter vendors and products based on the search input
    vendorSearchList.clear();
    productSearchList.clear();

    for (var element in vendorList) {
      if (element.title.toLowerCase().contains(text.toLowerCase())) {
        setState(() {
          vendorSearchList.add(element);
        });
      }
    }

    for (var element in productList) {
      // only add if it's published AND the name matches
      if (element.publish == true &&
          element.name.toLowerCase().contains(text.toLowerCase())) {
        productSearchList.add(element);
      }
    }
  }

  @override
  void dispose() {
    _searchFocusNode.dispose(); // Dispose the FocusNode
    _searchController.dispose();
    vendorSearchList.clear();
    productSearchList.clear();
    super.dispose();
  }

  data(VendorModel vendorModel) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () => push(
          context,
          NewVendorProductsScreen(
            vendorModel: vendorModel,
          )),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 4,
        ),
        child: Row(
          // crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            CachedNetworkImage(
                height: MediaQuery.of(context).size.height * 0.075,
                width: MediaQuery.of(context).size.width * 0.16,
                imageUrl: getImageVAlidUrl(vendorModel.photo),
                imageBuilder: (context, imageProvider) => Container(
                      // width: 100,
                      // height: 100,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          )),
                    ),
                errorWidget: (context, url, error) => ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Image.network(
                      AppGlobal.placeHolderImage!,
                      fit: BoxFit.cover,
                    ))),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(vendorModel.title,
                          style: TextStyle(
                            fontFamily: "Poppinsr",
                            fontSize: 16,
                            color: isDarkMode(context)
                                ? const Color(0xffFFFFFF)
                                : const Color(0xff272727),
                            // Color(0xff272727)
                          )),
                      const SizedBox(height: 3),
                      Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.location_on_sharp,
                              color: Color(0xff9091A4),
                              size: 16,
                            ),
                            const SizedBox(width: 3),
                            Container(
                                constraints: const BoxConstraints(
                                    maxWidth: 200, maxHeight: 50),
                                child: Text(
                                  vendorModel.location,
                                  maxLines: 1,
                                  style: const TextStyle(
                                      fontFamily: "Poppinsl",
                                      fontSize: 14,
                                      color: Color(0XFF555353)),
                                ))
                          ]),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  product(ProductModel productModel) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () async {
        VendorModel? vendorModel =
            await FireStoreUtils.getVendor(productModel.vendorID);
        if (vendorModel != null) {
          push(
            context,
            ProductDetailsScreen(
              vendorModel: vendorModel,
              productModel: productModel,
            ),
          );
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 4,
        ),
        child: Row(
          children: <Widget>[
            CachedNetworkImage(
                height: MediaQuery.of(context).size.height * 0.075,
                width: MediaQuery.of(context).size.width * 0.16,
                imageUrl: getImageVAlidUrl(productModel.photo),
                imageBuilder: (context, imageProvider) => Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          )),
                    ),
                errorWidget: (context, url, error) => ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Image.network(
                      AppGlobal.placeHolderImage!,
                      fit: BoxFit.cover,
                    ))),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      // Food Name
                      Text(productModel.name,
                          style: TextStyle(
                            fontFamily: "Poppinsr",
                            fontSize: 16,
                            color: isDarkMode(context)
                                ? const Color(0xffFFFFFF)
                                : const Color(0xff272727),
                          )),
                      const SizedBox(height: 3),
                      // Restaurant Name
                      FutureBuilder<VendorModel?>(
                        future: FireStoreUtils.getVendor(productModel.vendorID),
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Text(
                              'Loading restaurant...',
                              style: TextStyle(
                                fontFamily: "Poppinsl",
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            );
                          }
                          if (snapshot.hasError || snapshot.data == null) {
                            return const Text(
                              'Restaurant not found',
                              style: TextStyle(
                                fontFamily: "Poppinsl",
                                fontSize: 14,
                                color: Colors.red,
                              ),
                            );
                          }
                          return Text(
                            snapshot.data!.title,
                            style: const TextStyle(
                              fontFamily: "Poppinsl",
                              fontSize: 14,
                              color: Color(0XFF555353),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 5),
                      // Food Price
                      productModel.disPrice == "" ||
                              productModel.disPrice == "0"
                          ? Text(
                              "${amountShow(amount: productModel.price.toString())}",
                              style: TextStyle(
                                fontFamily: "Poppinsm",
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5,
                                color: Color(COLOR_PRIMARY),
                              ),
                            )
                          : Row(
                              children: [
                                Text(
                                  "${amountShow(amount: productModel.disPrice.toString())}",
                                  style: TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  "${amountShow(amount: productModel.price.toString())}",
                                  style: const TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey,
                                    decoration: TextDecoration.lineThrough,
                                  ),
                                ),
                              ],
                            ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
