import 'dart:async';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:foodie_customer/constants.dart';
import 'package:foodie_customer/main.dart';
import 'package:foodie_customer/model/OrderModel.dart';
import 'package:foodie_customer/services/FirebaseHelper.dart';
import 'package:foodie_customer/services/helper.dart';
import 'package:foodie_customer/ui/orderDetailsScreen/OrderDetailsScreen.dart';

class CurrentOrdersBanner extends StatelessWidget {
  const CurrentOrdersBanner({Key? key}) : super(key: key);

  bool _isActiveStatus(String status) {
    final s = status.toLowerCase();
    return !(s == 'order completed' ||
        s == 'completed' ||
        s == 'delivered' ||
        s == 'order cancelled' ||
        s == 'cancelled');
  }

  @override
  Widget build(BuildContext context) {
    if (MyAppState.currentUser == null ||
        MyAppState.currentUser!.userID.isEmpty) {
      return const SizedBox.shrink();
    }

    return StreamBuilder<List<OrderModel>>(
      stream: FireStoreUtils().getOrders(MyAppState.currentUser!.userID),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox.shrink();
        }

        if (!snapshot.hasData || (snapshot.data?.isEmpty ?? true)) {
          return const SizedBox.shrink();
        }

        final List<OrderModel> orders = snapshot.data!;
        final OrderModel activeOrder = orders.firstWhere(
          (o) => _isActiveStatus(o.status),
          orElse: () => OrderModel(status: '', id: ''),
        );

        if (activeOrder.id.isEmpty || !_isActiveStatus(activeOrder.status)) {
          return const SizedBox.shrink();
        }

        return _BannerContent(order: activeOrder);
      },
    );
  }
}

class _BannerContent extends StatefulWidget {
  final OrderModel order;
  const _BannerContent({Key? key, required this.order}) : super(key: key);

  @override
  State<_BannerContent> createState() => _BannerContentState();
}

class _BannerContentState extends State<_BannerContent> {
  Timer? _ticker;
  double _progress = 0.0; // 0..1

  @override
  void initState() {
    super.initState();
    _startTicker();
  }

  void _startTicker() {
    final int totalSeconds = _deriveTotalSecondsFromOrder();
    final DateTime start = widget.order.createdAt.toDate();
    void update() {
      final int elapsed = DateTime.now().difference(start).inSeconds;
      final int elapsedClamped = elapsed.clamp(0, totalSeconds);
      setState(() {
        _progress = elapsedClamped / totalSeconds;
      });
    }

    update();
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => update());
  }

  // Match parsing used in OrderDetailsScreen: supports "HH:mm" or minutes
  int _deriveTotalSecondsFromOrder() {
    final String raw = (widget.order.estimatedTimeToPrepare ?? '').trim();
    if (raw.isEmpty) {
      return 20 * 60; // default 20 minutes
    }

    if (raw.contains(':')) {
      final parts = raw.split(':');
      int hours = 0;
      int minutes = 0;
      if (parts.isNotEmpty) {
        hours = int.tryParse(parts[0].replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
      }
      if (parts.length > 1) {
        minutes = int.tryParse(parts[1].replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
      }
      final int seconds = hours * 3600 + minutes * 60;
      return seconds > 0 ? seconds : 20 * 60;
    }

    final match = RegExp(r"\d+").firstMatch(raw);
    final int minutes = int.tryParse(match?.group(0) ?? '') ?? 0;
    return ((minutes > 0 ? minutes : 20) * 60).clamp(60, 24 * 60 * 60);
  }

  String _formatEstimatedPrep() {
    final String raw = (widget.order.estimatedTimeToPrepare ?? '').trim();
    if (raw.isEmpty) {
      return '20m';
    }

    if (raw.contains(':')) {
      final parts = raw.split(':');
      final int hours =
          int.tryParse(parts[0].replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
      final int minutes = parts.length > 1
          ? int.tryParse(parts[1].replaceAll(RegExp(r'[^0-9]'), '')) ?? 0
          : 0;
      if (hours == 0) {
        return '${minutes > 0 ? minutes : 20}m';
      }
      return '${hours}h';
    }

    final match = RegExp(r"\d+").firstMatch(raw);
    final int minutes = int.tryParse(match?.group(0) ?? '') ?? 0;
    return '${minutes > 0 ? minutes : 20}m';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color bgColor =
        isDarkMode(context) ? const Color(DarkContainerColor) : Colors.white;
    final Color borderColor = Color(COLOR_PRIMARY);
    final String productImageUrl = (widget.order.products.isNotEmpty &&
            widget.order.products.first.photo.isNotEmpty)
        ? widget.order.products.first.photo
        : '';
    final String statusLower = widget.order.status.toLowerCase();
    final bool isPlaced =
        statusLower == 'order placed' || statusLower == 'placed';
    final String restaurantName =
        widget.order.vendor.title.isNotEmpty ? widget.order.vendor.title : '';
    final bool isAccepted =
        statusLower == 'order accepted' || statusLower == 'accepted';
    final bool isDriverAssigned = statusLower.contains('driver') &&
        (statusLower.contains('assigned') || statusLower.contains('pending'));
    final bool isDriverPending = statusLower == 'driver pending';
    final bool isInTransit = statusLower == 'in transit';

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor, width: 2),
          boxShadow: [
            isDarkMode(context)
                ? const BoxShadow()
                : BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
          ],
        ),
        child: InkWell(
          onTap: () {
            push(
              context,
              OrderDetailsScreen(orderModel: widget.order),
            );
          },
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  width: 52,
                  height: 52,
                  color: Color(COLOR_PRIMARY).withOpacity(0.08),
                  child: (isAccepted || isDriverAssigned || isInTransit)
                      ? Stack(
                          alignment: Alignment.center,
                          children: [
                            // Background track (full circle, light grey)
                            SizedBox(
                              width: 46,
                              height: 46,
                              child: CircularProgressIndicator(
                                value: 1,
                                strokeWidth: 5,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.black12,
                                ),
                              ),
                            ),
                            // Foreground progress according to restaurant estimate
                            SizedBox(
                              width: 46,
                              height: 46,
                              child: CircularProgressIndicator(
                                value: _progress.clamp(0.0, 1.0),
                                strokeWidth: 5,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Color(COLOR_PRIMARY),
                                ),
                                backgroundColor: Colors.transparent,
                              ),
                            ),
                            // Remaining minutes in center
                            Text(
                              _formatEstimatedPrep(),
                              style: TextStyle(
                                fontFamily: 'Poppinsm',
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: isDarkMode(context)
                                    ? Colors.white
                                    : const Color(0xFF000000),
                              ),
                            ),
                          ],
                        )
                      : (productImageUrl.isNotEmpty
                          ? Image.network(
                              getImageVAlidUrl(productImageUrl),
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Icon(
                                Icons.fastfood,
                                color: Color(COLOR_PRIMARY),
                              ),
                            )
                          : Icon(
                              Icons.fastfood,
                              color: Color(COLOR_PRIMARY),
                            )),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (isPlaced) ...[
                      Text(
                        'We have sent your order to'.tr(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        restaurantName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                        ),
                      ),
                    ] else if (isAccepted) ...[
                      Text(
                        'Your order is on the way to'.tr(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        restaurantName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Estimate time for preparation of your orders'.tr(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 12,
                          color: isDarkMode(context)
                              ? Colors.white70
                              : const Color(0xFF666666),
                        ),
                      ),
                    ] else ...[
                      Text(
                        (isDriverPending
                                ? 'Your rider found'
                                : isDriverAssigned
                                    ? 'Looking for delivery riders'
                                    : 'Your order is on the way')
                            .tr(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Poppinsm',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                        ),
                      ),
                      const SizedBox(height: 2),
                    ],
                    Text(
                      widget.order.status.tr(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'Poppinsm',
                        fontSize: 12,
                        color: isDarkMode(context)
                            ? Colors.white70
                            : const Color(0xFF666666),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              TextButton(
                onPressed: () {
                  push(
                    context,
                    OrderDetailsScreen(orderModel: widget.order),
                  );
                },
                style: TextButton.styleFrom(
                  foregroundColor: Colors.transparent,
                  backgroundColor: Colors.transparent,
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(36, 36),
                ),
                child: SizedBox(
                  width: 70,
                  height: 70,
                  child: isDriverPending
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(35),
                          child: widget.order.driver?.profilePictureURL !=
                                      null &&
                                  widget.order.driver!.profilePictureURL
                                      .isNotEmpty
                              ? Image.network(
                                  getImageVAlidUrl(
                                      widget.order.driver!.profilePictureURL),
                                  fit: BoxFit.cover,
                                  width: 70,
                                  height: 70,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Container(
                                    width: 70,
                                    height: 70,
                                    decoration: BoxDecoration(
                                      color:
                                          Color(COLOR_PRIMARY).withOpacity(0.1),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      Icons.person,
                                      size: 35,
                                      color: Color(COLOR_PRIMARY),
                                    ),
                                  ),
                                )
                              : Container(
                                  width: 70,
                                  height: 70,
                                  decoration: BoxDecoration(
                                    color:
                                        Color(COLOR_PRIMARY).withOpacity(0.1),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.person,
                                    size: 35,
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                ),
                        )
                      : Image.asset(
                          'assets/design.png',
                          fit: BoxFit.contain,
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
