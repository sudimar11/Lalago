import 'dart:async';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';

import 'package:clipboard/clipboard.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';

import 'package:foodie_customer/AppGlobal.dart';

import 'package:foodie_customer/constants.dart';

import 'package:foodie_customer/main.dart';

import 'package:foodie_customer/model/AddressModel.dart';

import 'package:foodie_customer/model/BannerModel.dart';

import 'package:foodie_customer/model/FavouriteModel.dart';

import 'package:foodie_customer/model/ProductModel.dart';

import 'package:foodie_customer/model/User.dart';

import 'package:foodie_customer/model/VendorCategoryModel.dart';

import 'package:foodie_customer/model/VendorModel.dart';

import 'package:foodie_customer/model/offer_model.dart';

import 'package:foodie_customer/model/OrderModel.dart';

import 'package:foodie_customer/model/story_model.dart';

import 'package:foodie_customer/services/FirebaseHelper.dart';

import 'package:foodie_customer/services/helper.dart';

import 'package:foodie_customer/services/localDatabase.dart';

import 'package:foodie_customer/ui/categoryDetailsScreen/CategoryDetailsScreen.dart';

import 'package:foodie_customer/ui/cuisinesScreen/CuisinesScreen.dart';

import 'package:foodie_customer/ui/deliveryAddressScreen/DeliveryAddressScreen.dart';

import 'package:foodie_customer/ui/home/view_all_category_product_screen.dart';

import 'package:foodie_customer/ui/home/view_all_new_arrival_restaurant_screen.dart';
import 'package:foodie_customer/ui/home/view_all_offer_screen.dart';

import 'package:foodie_customer/ui/home/view_all_popular_food_near_by_screen.dart';

import 'package:foodie_customer/ui/home/view_all_popular_restaurant_screen.dart';

import 'package:foodie_customer/ui/home/view_all_restaurant.dart';
import 'package:foodie_customer/ui/home/view_all_sulit_foods_screen.dart';

import 'package:foodie_customer/ui/productDetailsScreen/ProductDetailsScreen.dart';

import 'package:foodie_customer/ui/searchScreen/SearchScreen.dart';

import 'package:foodie_customer/ui/vendorProductsScreen/newVendorProductsScreen.dart';

import 'package:foodie_customer/widget/permission_dialog.dart';

import 'package:geocoding/geocoding.dart';

import 'package:geolocator/geolocator.dart';

import 'package:location/location.dart' as loc;

import 'package:location/location.dart';

import 'package:provider/provider.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'package:story_view/story_view.dart';

import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:google_maps_place_picker_mb/google_maps_place_picker.dart';
import 'package:foodie_customer/ui/home/food_varieties.dart';
import 'package:foodie_customer/ui/home/current_orders_banner.dart';

// Separate widget for rotating hint text
class RotatingHintText extends StatefulWidget {
  final List<String> hints;
  final Duration interval;
  final TextStyle? textStyle;

  const RotatingHintText({
    Key? key,
    required this.hints,
    this.interval = const Duration(seconds: 3),
    this.textStyle,
  }) : super(key: key);

  @override
  State<RotatingHintText> createState() => _RotatingHintTextState();
}

class _RotatingHintTextState extends State<RotatingHintText> {
  int currentIndex = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    timer = Timer.periodic(widget.interval, (timer) {
      if (mounted) {
        setState(() {
          currentIndex = (currentIndex + 1) % widget.hints.length;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: Duration(milliseconds: 500),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(
          opacity: animation,
          child: child,
        );
      },
      child: Text(
        widget.hints[currentIndex],
        key: ValueKey(currentIndex),
        style: widget.textStyle ??
            const TextStyle(
              color: Color(0xFF9CA3AF),
              fontFamily: 'Poppins',
              fontSize: 16,
              fontWeight: FontWeight.w400,
            ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final User? user;

  HomeScreen({Key? key, this.user}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  //String lastSearch = '';
  late List<ProductModel> allProducts = [];
  List<ProductModel> recommendedProducts = [];
  final fireStoreUtils = FireStoreUtils();

  late Future<List<ProductModel>> productsFuture;

  // final PageController _controller =
  //     PageController(viewportFraction: 0.8, keepPage: true);

  List<VendorModel> vendors = [];

  List<VendorModel> popularRestaurantLst = [];

  List<VendorModel> newArrivalLst = [];

  List<VendorModel> offerVendorList = [];

  List<OfferModel> offersList = [];

  Stream<List<VendorModel>>? lstAllRestaurant;

  List<ProductModel> lstNearByFood = [];

  // Order Again section
  List<ProductModel> orderAgainProducts = [];
  bool isLoadingOrderAgain = true;
  StreamSubscription<List<OrderModel>>? orderAgainStreamSubscription;

  // Meal for One • Sulit price section
  List<ProductModel> mealForOneProducts = [];
  bool isLoadingMealForOne = true;
  static const double sulitCap = 150.0; // Price cap for sulit meals (in pesos)

  //Stream<List<FavouriteModel>>? lstFavourites;

  late Future<List<FavouriteModel>> lstFavourites;

  List<String> lstFav = [];

  String? name = "";

  String? selctedOrderTypeValue = "Delivery".tr();

  bool isLocationPermissionAllowed = false;

  loc.Location location = loc.Location();

  // Database db;

  // Rotating hint variables
  List<String> rotatingHints = [
    'Nag lalawag lamay?',
    'Search Tiyulah itum',
    'May cravings ka?',
    'Search restaurant',
    'Search shawarma',
    'Search pizza',
    'Mahapdi na?',
    'Search mo way biddah'
  ];

  List<VendorCategoryModel> categoryWiseProductList = [];

  List<BannerModel> bannerTopHome = [];

  List<BannerModel> bannerMiddleHome = [];

  bool isHomeBannerLoading = true;

  bool isHomeBannerMiddleLoading = true;

  List<OfferModel> offerList = [];

  bool? storyEnable = false;

  @override
  void initState() {
    super.initState();
    // Fetch the last search term
    fetchAllProducts();
    fetchLastSearchAndUpdateRecommendations();
    fetchOrderAgainProducts();
    fetchMealForOneProducts();

    getLocationData();

    getBanner();
  }

  getBanner() async {
    await fireStoreUtils.getHomeTopBanner().then((value) {
      setState(() {
        bannerTopHome = value;

        isHomeBannerLoading = false;
      });
    });

    await fireStoreUtils.getHomePageShowCategory().then((value) {
      setState(() {
        categoryWiseProductList = value;
      });
    });

    await fireStoreUtils.getHomeMiddleBanner().then((value) {
      setState(() {
        bannerMiddleHome = value;

        isHomeBannerMiddleLoading = false;
      });
    });

    await FireStoreUtils().getPublicCoupons().then((value) {
      setState(() {
        offerList = value;
      });
    });

    await FirebaseFirestore.instance
        .collection(Setting)
        .doc('story')
        .get()
        .then((value) {
      setState(() {
        storyEnable = value.data()!['isEnabled'];
      });
    });
  }

  Future<void> fetchAllProducts() async {
    List<ProductModel> products = await fireStoreUtils.getAllProducts();
    setState(() {
      allProducts = products; // Populate global product list
    });
    generateRecommendations(); // Generate initial recommendations
    fetchOrderAgainProducts(); // Fetch order again products after all products are loaded
    fetchMealForOneProducts(); // Fetch meal for one products after all products are loaded
  }

  void fetchLastSearchAndUpdateRecommendations() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Fetch the last search term
    String lastSearch = prefs.getString('lastSearch') ?? '';

    // Filter recommendations based on the last search term
    setState(() {
      recommendedProducts = allProducts.where((product) {
        return product.name.toLowerCase().contains(lastSearch.toLowerCase());
      }).toList();
    });
  }

  void generateRecommendations() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Fetch the last search term
    String lastSearch = prefs.getString('lastSearch') ?? '';

    // Initialize recommendations list
    List<ProductModel> recommendations = [];

    // Add products matching the last search term
    if (lastSearch.isNotEmpty) {
      recommendations.addAll(allProducts.where((product) =>
          product.name.toLowerCase().contains(lastSearch.toLowerCase())));
    }

    // Add frequently ordered products (mock logic here; replace with actual user activity tracking)
    List<String> frequentOrders = [
      'product1',
      'product2'
    ]; // Example product IDs
    recommendations.addAll(
        allProducts.where((product) => frequentOrders.contains(product.id)));

    // Add trending products as fallback

    // Remove duplicates and limit to top 10 recommendations
    recommendations = recommendations.toSet().toList();
    recommendations = recommendations.take(10).toList();

    // Update the UI with new recommendations
    setState(() {
      recommendedProducts = recommendations;
    });
  }

  // Fetch order again products from user's completed orders
  Future<void> fetchOrderAgainProducts() async {
    print('🔍 fetchOrderAgainProducts: Starting...');
    if (MyAppState.currentUser == null) {
      print('⚠️ fetchOrderAgainProducts: No current user');
      if (!mounted) return;
      setState(() {
        isLoadingOrderAgain = false;
      });
      return;
    }

    try {
      setState(() {
        isLoadingOrderAgain = true;
      });

      print(
          '🔍 fetchOrderAgainProducts: Getting orders for user ${MyAppState.currentUser!.userID}');

      // Cancel any existing subscription
      orderAgainStreamSubscription?.cancel();

      // Listen to the orders stream
      orderAgainStreamSubscription =
          fireStoreUtils.getOrders(MyAppState.currentUser!.userID).listen(
        (List<OrderModel> allOrders) async {
          print(
              '🔍 fetchOrderAgainProducts: Received ${allOrders.length} orders from stream');

          // Filter for completed orders using correct status values
          List<OrderModel> completedOrders = allOrders.where((order) {
            bool isCompleted =
                order.status.toLowerCase().contains('completed') ||
                    order.status.toLowerCase().contains('delivered') ||
                    order.status == ORDER_STATUS_COMPLETED;
            if (isCompleted) {
              print(
                  '✅ Found completed order: ${order.id} - Status: ${order.status}');
            }
            return isCompleted;
          }).toList();

          print(
              '🔍 fetchOrderAgainProducts: Found ${completedOrders.length} completed orders');

          if (completedOrders.isEmpty) {
            print('⚠️ fetchOrderAgainProducts: No completed orders found');
            if (!mounted) return;
            setState(() {
              orderAgainProducts = [];
              isLoadingOrderAgain = false;
            });
            return;
          }

          // Wait for allProducts to be loaded
          if (allProducts.isEmpty) {
            print(
                '⚠️ fetchOrderAgainProducts: allProducts is empty, waiting...');
            await Future.delayed(Duration(seconds: 1));
            if (!mounted) return;
          }

          // Extract product IDs from completed orders
          Set<String> productIds = {};
          for (OrderModel order in completedOrders) {
            for (var product in order.products) {
              // Extract the base product ID (remove variant suffix if exists)
              String baseProductId = product.id.contains('~')
                  ? product.id.split('~').first
                  : product.id;
              productIds.add(baseProductId);
              print(
                  '🔍 Added product ID: $baseProductId from order ${order.id}');
            }
          }

          print(
              '🔍 fetchOrderAgainProducts: Found ${productIds.length} unique product IDs');

          // Map product IDs to ProductModels
          List<ProductModel> orderAgainList = [];
          for (String productId in productIds) {
            try {
              ProductModel? product = allProducts.firstWhere(
                (p) => p.id == productId,
                orElse: () => ProductModel(),
              );
              if (product.id.isNotEmpty) {
                orderAgainList.add(product);
                print('✅ Found product: ${product.name} (ID: ${product.id})');
              } else {
                print('⚠️ Product not found for ID: $productId');
              }
            } catch (e) {
              print('❌ Error finding product for ID $productId: $e');
            }
          }

          // Remove duplicates and limit to 10 items
          orderAgainList = orderAgainList.toSet().toList();
          orderAgainList = orderAgainList.take(10).toList();

          print(
              '🔍 fetchOrderAgainProducts: Final list has ${orderAgainList.length} products');

          if (!mounted) return;
          setState(() {
            orderAgainProducts = orderAgainList;
            isLoadingOrderAgain = false;
          });
        },
        onError: (error) {
          print('❌ fetchOrderAgainProducts: Stream error: $error');
          if (!mounted) return;
          setState(() {
            isLoadingOrderAgain = false;
          });
        },
      );
    } catch (e) {
      print('❌ fetchOrderAgainProducts: Exception: $e');
      if (!mounted) return;
      setState(() {
        isLoadingOrderAgain = false;
      });
    }
  }

  // Fetch meal for one products (sulit price)
  Future<void> fetchMealForOneProducts() async {
    try {
      List<ProductModel> mealForOneList = [];

      for (ProductModel product in allProducts) {
        // Check if product price is within sulit cap
        double productPrice = double.tryParse(product.price) ?? 0.0;
        if (productPrice <= sulitCap && productPrice > 0) {
          // Check for solo indicators in name, description, or tags
          String productName = product.name.toLowerCase();
          String productDesc = product.description.toLowerCase();

          // Keywords that indicate solo/individual meals
          List<String> soloKeywords = [
            'solo',
            'single',
            'individual',
            'one',
            '1',
            'personal',
            'meal',
            'combo',
            'set',
            'plate',
            'serving',
            'portion'
          ];

          bool isSoloMeal = soloKeywords.any((keyword) =>
              productName.contains(keyword) || productDesc.contains(keyword));

          // Also check if the product name suggests it's for one person
          if (isSoloMeal ||
              productName.contains('meal') ||
              productName.contains('combo')) {
            mealForOneList.add(product);
          }
        }
      }

      // Remove duplicates and limit to 10 items
      mealForOneList = mealForOneList.toSet().toList();
      mealForOneList = mealForOneList.take(10).toList();

      if (!mounted) return;
      setState(() {
        mealForOneProducts = mealForOneList;
        isLoadingMealForOne = false;
      });
    } catch (e) {
      print('Error fetching meal for one products: $e');
      if (!mounted) return;
      setState(() {
        isLoadingMealForOne = false;
      });
    }
  }

  // Custom header for Meal for One section
  Widget _mealForOneHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Meal for one ",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: isDarkMode(context)
                              ? Colors.white
                              : Colors.black87,
                        ),
                      ),
                      TextSpan(
                        text: "sulit prices",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(
                              COLOR_PRIMARY), // Primary color for "sulit prices"
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "P30 Delivery Fee no min. spend",
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color:
                        isDarkMode(context) ? Colors.white70 : Colors.black54,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              final List<ProductModel> sulitAll = allProducts.where((p) {
                final double price = double.tryParse(p.price) ?? 0.0;
                return price > 0 && price <= sulitCap;
              }).toList();

              push(
                context,
                ViewAllSulitFoodsScreen(
                  sulitProducts: sulitAll,
                  vendors: vendors,
                ),
              );
            },
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                Icons.arrow_forward_ios_rounded,
                size: 16,
                color: Colors.grey.shade600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Custom card for Meal for One section
  Widget _mealForOneCard(ProductModel product, VendorModel vendor) {
    return GestureDetector(
      onTap: () {
        push(
          context,
          ProductDetailsScreen(productModel: product, vendorModel: vendor),
        );
      },
      child: Container(
        width: MediaQuery.of(context).size.width * 0.375,
        margin: const EdgeInsets.only(right: 12, bottom: 8),
        decoration: BoxDecoration(
          color: isDarkMode(context) ? Color(DARK_CARD_BG_COLOR) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(
            color: isDarkMode(context)
                ? Color(DarkContainerBorderColor)
                : Colors.grey.shade100,
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image section with restaurant logo
            Stack(
              children: [
                // Main product image
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                    child: CachedNetworkImage(
                      imageUrl: getImageVAlidUrl(product.photo),
                      fit: BoxFit.cover,
                      placeholder: (context, url) => Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 40,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      errorWidget: (context, url, error) => Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.error,
                            size: 40,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Restaurant logo overlay
                Positioned(
                  bottom: 8,
                  left: 8,
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: CachedNetworkImage(
                        imageUrl: getImageVAlidUrl(vendor.photo),
                        fit: BoxFit.cover,
                        placeholder: (context, url) => const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 16,
                            color: Colors.grey,
                          ),
                        ),
                        errorWidget: (context, url, error) => const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            // Content section
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Restaurant name and rating
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          vendor.title,
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: isDarkMode(context)
                                ? Colors.white
                                : Colors.black87,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const Icon(
                        Icons.star,
                        size: 12,
                        color: Colors.amber,
                      ),
                      const SizedBox(width: 2),
                      Text(
                        vendor.reviewsCount != 0
                            ? '${(vendor.reviewsSum / vendor.reviewsCount).toStringAsFixed(1)}'
                            : '0.0',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: isDarkMode(context)
                              ? Colors.white70
                              : Colors.black54,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  // Product name
                  Text(
                    product.name,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color:
                          isDarkMode(context) ? Colors.white : Colors.black87,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  // Price and delivery fee
                  Row(
                    children: [
                      Text(
                        '₱ ${product.price}',
                        style: TextStyle(
                          fontFamily: "Poppinsm",
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Color(COLOR_PRIMARY),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: Colors.green.shade200),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.delivery_dining,
                              size: 10,
                              color: Colors.green.shade600,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              '₱ 30.00',
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: Colors.green.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Order Again card with same design as Meal for One cards
  Widget _orderAgainCard(ProductModel product, VendorModel vendor) {
    return GestureDetector(
      onTap: () {
        push(
          context,
          ProductDetailsScreen(productModel: product, vendorModel: vendor),
        );
      },
      child: Container(
        width: MediaQuery.of(context).size.width * 0.375,
        margin: const EdgeInsets.only(right: 12, bottom: 8),
        decoration: BoxDecoration(
          color: isDarkMode(context) ? Color(DARK_CARD_BG_COLOR) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(
            color: isDarkMode(context)
                ? Color(DarkContainerBorderColor)
                : Colors.grey.shade100,
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image section with restaurant logo
            Stack(
              children: [
                // Main product image
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                    child: CachedNetworkImage(
                      imageUrl: getImageVAlidUrl(product.photo),
                      fit: BoxFit.cover,
                      placeholder: (context, url) => Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 40,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      errorWidget: (context, url, error) => Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.error,
                            size: 40,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Restaurant logo overlay
                Positioned(
                  bottom: 8,
                  left: 8,
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: CachedNetworkImage(
                        imageUrl: getImageVAlidUrl(vendor.photo),
                        fit: BoxFit.cover,
                        placeholder: (context, url) => const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 16,
                            color: Colors.grey,
                          ),
                        ),
                        errorWidget: (context, url, error) => const Center(
                          child: Icon(
                            Icons.restaurant,
                            size: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // "Order Again" badge
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Color(COLOR_PRIMARY),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.refresh,
                          size: 10,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 2),
                        Text(
                          'Again',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            // Content section
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Restaurant name and rating
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          vendor.title,
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: isDarkMode(context)
                                ? Colors.white
                                : Colors.black87,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const Icon(
                        Icons.star,
                        size: 12,
                        color: Colors.amber,
                      ),
                      const SizedBox(width: 2),
                      Text(
                        vendor.reviewsCount != 0
                            ? '${(vendor.reviewsSum / vendor.reviewsCount).toStringAsFixed(1)}'
                            : '0.0',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: isDarkMode(context)
                              ? Colors.white70
                              : Colors.black54,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  // Product name
                  Text(
                    product.name,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color:
                          isDarkMode(context) ? Colors.white : Colors.black87,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  // Price and order again indicator
                  Row(
                    children: [
                      Text(
                        product.disPrice != "" && product.disPrice != "0"
                            ? '₱ ${product.disPrice}'
                            : '₱ ${product.price}',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Color(COLOR_PRIMARY),
                        ),
                      ),
                      if (product.disPrice != "" && product.disPrice != "0")
                        Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Text(
                            '₱ ${product.price}',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                              color: Colors.grey.shade600,
                              decoration: TextDecoration.lineThrough,
                            ),
                          ),
                        ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade50,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: Colors.orange.shade200),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.history,
                              size: 10,
                              color: Colors.orange.shade600,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              'Ordered',
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: Colors.orange.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // First-time user promo card shown above Stories
  Widget _firstTimePromoCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
      child: GestureDetector(
        onTap: () {
          push(
            context,
            const ViewAllPopularRestaurantScreen(),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.orange.shade400,
                Colors.deepOrange.shade400,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 32,
                offset: const Offset(0, 16),
              ),
            ],
          ),
          child: Stack(
            children: [
              // subtle decorative circles
              Positioned(
                right: -20,
                top: -20,
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Positioned(
                right: 20,
                bottom: -10,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "First-time with LalaGO?".tr(),
                            style: const TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.white,
                              letterSpacing: 0.2,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Enjoy ₱20 OFF your first order, only for new customers!\nTap Order Now and taste the savings."
                                .tr(),
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1.35,
                              color: Colors.white.withOpacity(0.95),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.shopping_bag_rounded,
                                    size: 16,
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    "Order Now".tr(),
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: Color(COLOR_PRIMARY),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(
                        child: Image.asset(
                          'assets/images/riderlogo.png',
                          width: 70,
                          height: 70,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: isDarkMode(context)
          ? const Color.fromARGB(255, 201, 144, 1)
          : const Color(0xffFFFFFF),
      body: isLoading == true
          ? Center(child: CircularProgressIndicator())
          : (MyAppState.selectedPosotion.location!.latitude == 0 &&
                  MyAppState.selectedPosotion.location!.longitude == 0)
              ? Center(
                  child: showEmptyState(
                      "We don't have your location.".tr(), context,
                      description:
                          "Set your location to started searching for restaurants in your area"
                              .tr(), action: () async {
                    checkPermission(
                      () async {
                        await showProgress(
                            context, "Please wait...".tr(), false);

                        AddressModel addressModel = AddressModel();

                        try {
                          LocationPermission permission =
                              await requestLocationWithDialog(context);

                          await Geolocator.getCurrentPosition();

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PlacePicker(
                                apiKey: GOOGLE_API_KEY,

                                onPlacePicked: (result) async {
                                  await hideProgress();

                                  AddressModel addressModel = AddressModel();

                                  addressModel.locality =
                                      result.formattedAddress!.toString();

                                  addressModel.location = UserLocation(
                                      latitude: result.geometry!.location.lat,
                                      longitude: result.geometry!.location.lng);

                                  MyAppState.selectedPosotion = addressModel;

                                  if (mounted) {
                                    setState(() {});
                                  }

                                  getData();

                                  Navigator.of(context).pop();
                                },

                                initialPosition:
                                    LatLng(-33.8567844, 151.213108),

                                useCurrentLocation: true,

                                selectInitialPosition: true,

                                usePinPointingSearch: true,

                                usePlaceDetailSearch: true,

                                zoomGesturesEnabled: true,

                                zoomControlsEnabled: true,

                                resizeToAvoidBottomInset:
                                    false, // only works in page mode, less flickery, remove if wrong offsets
                              ),
                            ),
                          );
                        } catch (e) {
                          await placemarkFromCoordinates(19.228825, 72.854118)
                              .then((valuePlaceMaker) {
                            Placemark placeMark = valuePlaceMaker[0];

                            setState(() {
                              addressModel.location = UserLocation(
                                  latitude: 19.228825, longitude: 72.854118);

                              String currentLocation =
                                  "${placeMark.name}, ${placeMark.subLocality}, ${placeMark.locality}, ${placeMark.administrativeArea}, ${placeMark.postalCode}, ${placeMark.country}";

                              addressModel.locality = currentLocation;
                            });
                          });

                          MyAppState.selectedPosotion = addressModel;

                          await hideProgress();

                          getData();
                        }
                      },
                    );
                  }, buttonTitle: 'Select'.tr()),
                )
              : Stack(children: [
                  SingleChildScrollView(
                    child: Container(
                      color: isDarkMode(context)
                          ? const Color.fromARGB(255, 212, 197, 128)
                          : const Color(0xffFFFFFF),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Stack(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage('assets/pis.jpg'),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 10.0),
                                          child: Row(
                                            children: [
                                              Image.asset(
                                                'assets/images/riderlogo.png',
                                                width: 50,
                                                height: 50,
                                                fit: BoxFit.contain,
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Column(
                                                children: [
                                                  Image.asset(
                                                    'assets/images/namewith.png',
                                                    width: 90,
                                                    height: 60,
                                                    fit: BoxFit.contain,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                            padding: const EdgeInsets.only(
                                                left: 10, right: 10, bottom: 5),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Center(
                                                    child: Text(
                                                      "Search food or restaurants"
                                                          .tr(),
                                                      style: TextStyle(
                                                        fontSize: 20,
                                                        color: Colors.white,
                                                        fontFamily: "Poppinssb",
                                                      ),
                                                    ).tr(),
                                                  ),
                                                ),
                                                Visibility(
                                                  visible: selctedOrderTypeValue ==
                                                      null, // Modify this condition as needed

                                                  child: DropdownButton(
                                                    value:
                                                        selctedOrderTypeValue,
                                                    isDense: true,
                                                    dropdownColor: Colors.black,
                                                    onChanged:
                                                        (newValue) async {
                                                      int cartProd = 0;

                                                      await Provider.of<
                                                                  CartDatabase>(
                                                              context,
                                                              listen: false)
                                                          .allCartProducts
                                                          .then((value) {
                                                        cartProd = value.length;
                                                      });

                                                      if (cartProd > 0) {
                                                        showDialog(
                                                          context: context,
                                                          builder: (BuildContext
                                                                  context) =>
                                                              ShowDialogToDismiss(
                                                            title: '',
                                                            content:
                                                                "Do you really want to change the delivery option?"
                                                                        .tr() +
                                                                    " Your cart will be empty"
                                                                        .tr(),
                                                            buttonText:
                                                                'CLOSE'.tr(),
                                                            secondaryButtonText:
                                                                'OK'.tr(),
                                                            action: () {
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();

                                                              Provider.of<CartDatabase>(
                                                                      context,
                                                                      listen:
                                                                          false)
                                                                  .deleteAllProducts();

                                                              setState(() {
                                                                selctedOrderTypeValue =
                                                                    newValue
                                                                        .toString();

                                                                saveFoodTypeValue();

                                                                getData();
                                                              });
                                                            },
                                                          ),
                                                        );
                                                      } else {
                                                        setState(() {
                                                          selctedOrderTypeValue =
                                                              newValue
                                                                  .toString();

                                                          saveFoodTypeValue();

                                                          getData();
                                                        });
                                                      }
                                                    },
                                                    icon: const Icon(
                                                      Icons.keyboard_arrow_down,
                                                      color: Colors.white,
                                                    ),
                                                    items: [
                                                      'Delivery'.tr(),
                                                      'Takeaway'.tr(),
                                                    ].map((location) {
                                                      return DropdownMenuItem(
                                                        child: Text(
                                                          location,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                        value: location,
                                                      );
                                                    }).toList(),
                                                  ),
                                                ),
                                              ],
                                            )),
                                        InkWell(
                                          onTap: () {
                                            push(context, const SearchScreen());
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 16),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                gradient: LinearGradient(
                                                  colors: [
                                                    Colors.white,
                                                    Color(0xFFF8FAFC),
                                                  ],
                                                  begin: Alignment.topLeft,
                                                  end: Alignment.bottomRight,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(25.0),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(0.08),
                                                    blurRadius: 20,
                                                    offset: Offset(0, 8),
                                                    spreadRadius: 0,
                                                  ),
                                                  BoxShadow(
                                                    color: Colors.white
                                                        .withOpacity(0.8),
                                                    blurRadius: 1,
                                                    offset: Offset(0, 1),
                                                    spreadRadius: 0,
                                                  ),
                                                ],
                                                border: Border.all(
                                                  color: Colors.grey.shade100,
                                                  width: 1.5,
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        left: 16, right: 12),
                                                    padding: EdgeInsets.all(8),
                                                    decoration: BoxDecoration(
                                                      gradient: LinearGradient(
                                                        colors: [
                                                          Color(0xFFFF8C42),
                                                          Color(0xFFFF6B35),
                                                        ],
                                                        begin:
                                                            Alignment.topLeft,
                                                        end: Alignment
                                                            .bottomRight,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Color(
                                                                  0xFFFF8C42)
                                                              .withOpacity(0.3),
                                                          blurRadius: 8,
                                                          offset: Offset(0, 4),
                                                          spreadRadius: 0,
                                                        ),
                                                      ],
                                                    ),
                                                    child: Icon(
                                                      Icons.search_rounded,
                                                      color: Colors.white,
                                                      size: 20,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                        right: 16,
                                                        top: 16,
                                                        bottom: 16,
                                                      ),
                                                      child: RotatingHintText(
                                                        hints: rotatingHints,
                                                        interval: Duration(
                                                            seconds: 3),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        right: 12),
                                                    padding: EdgeInsets.all(6),
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFFF1F5F9),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                    ),
                                                    child: Icon(
                                                      Icons.mic_rounded,
                                                      color: Color(0xFF64748B),
                                                      size: 18,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 20),
                                            child: Row(
                                              children: [
                                                Icon(
                                                  Icons.location_on_outlined,
                                                  color: Color.fromARGB(
                                                      255, 236, 230, 229),
                                                  size: 25,
                                                ),
                                                const SizedBox(
                                                  width: 5,
                                                ),
                                                Expanded(
                                                  child: Text(
                                                          MyAppState
                                                              .selectedPosotion
                                                              .getFullAddress()
                                                              .toString(),
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontFamily:
                                                                  "Poppinsr"))
                                                      .tr(),
                                                ),
                                                ElevatedButton(
                                                    onPressed: () async {
                                                      if (MyAppState
                                                              .currentUser !=
                                                          null) {
                                                        await Navigator.of(
                                                                context)
                                                            .push(MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        DeliveryAddressScreen()))
                                                            .then((value) {
                                                          if (value != null) {
                                                            AddressModel
                                                                addressModel =
                                                                value;

                                                            MyAppState
                                                                    .selectedPosotion =
                                                                addressModel;

                                                            if (mounted) {
                                                              setState(() {});
                                                            }

                                                            getData();
                                                          }
                                                        });
                                                      } else {
                                                        checkPermission(
                                                          () async {
                                                            await showProgress(
                                                                context,
                                                                "Please wait..."
                                                                    .tr(),
                                                                true);

                                                            AddressModel
                                                                addressModel =
                                                                AddressModel();

                                                            try {
                                                              await Geolocator
                                                                  .requestPermission();

                                                              await Geolocator
                                                                  .getCurrentPosition();

                                                              await hideProgress();

                                                              Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          PlacePicker(
                                                                    apiKey:
                                                                        GOOGLE_API_KEY,

                                                                    onPlacePicked:
                                                                        (result) async {
                                                                      print(
                                                                          "-========>");

                                                                      print(
                                                                          result);

                                                                      await hideProgress();

                                                                      AddressModel
                                                                          addressModel =
                                                                          AddressModel();

                                                                      addressModel
                                                                              .locality =
                                                                          result
                                                                              .formattedAddress!
                                                                              .toString();

                                                                      addressModel.location = UserLocation(
                                                                          latitude: result
                                                                              .geometry!
                                                                              .location
                                                                              .lat,
                                                                          longitude: result
                                                                              .geometry!
                                                                              .location
                                                                              .lng);

                                                                      MyAppState
                                                                              .selectedPosotion =
                                                                          addressModel;

                                                                      setState(
                                                                          () {});

                                                                      getData();

                                                                      Navigator.of(
                                                                              context)
                                                                          .pop();
                                                                    },

                                                                    initialPosition: LatLng(
                                                                        -33.8567844,
                                                                        151.213108),

                                                                    useCurrentLocation:
                                                                        true,

                                                                    selectInitialPosition:
                                                                        true,

                                                                    usePinPointingSearch:
                                                                        true,

                                                                    usePlaceDetailSearch:
                                                                        true,

                                                                    zoomGesturesEnabled:
                                                                        true,

                                                                    zoomControlsEnabled:
                                                                        true,

                                                                    resizeToAvoidBottomInset:
                                                                        false, // only works in page mode, less flickery, remove if wrong offsets
                                                                  ),
                                                                ),
                                                              );
                                                            } catch (e) {
                                                              await placemarkFromCoordinates(
                                                                      19.228825,
                                                                      72.854118)
                                                                  .then(
                                                                      (valuePlaceMaker) {
                                                                Placemark
                                                                    placeMark =
                                                                    valuePlaceMaker[
                                                                        0];

                                                                setState(() {
                                                                  addressModel.location = UserLocation(
                                                                      latitude:
                                                                          19.228825,
                                                                      longitude:
                                                                          72.854118);

                                                                  String
                                                                      currentLocation =
                                                                      "${placeMark.name}, ${placeMark.subLocality}, ${placeMark.locality}, ${placeMark.administrativeArea}, ${placeMark.postalCode}, ${placeMark.country}";

                                                                  addressModel
                                                                          .locality =
                                                                      currentLocation;
                                                                });
                                                              });

                                                              MyAppState
                                                                      .selectedPosotion =
                                                                  addressModel;

                                                              await hideProgress();

                                                              getData();
                                                            }
                                                          },
                                                        );
                                                      }
                                                    },
                                                    child: Text("Change".tr()),
                                                    style: ElevatedButton
                                                        .styleFrom(
                                                      backgroundColor:
                                                          Colors.white,
                                                      foregroundColor:
                                                          Color(COLOR_PRIMARY),
                                                      shape:
                                                          RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10)),
                                                      elevation: 3.0,
                                                    )),
                                              ],
                                            )),
                                      ]),
                                ),
                              ],
                            ),
                          ),

                          _firstTimePromoCard(),
                          storyWidget(),

                          Container(
                            color: isDarkMode(context)
                                ? const Color(DARK_COLOR)
                                : const Color(0xffFFFFFF),
                            child: FutureBuilder<List<VendorCategoryModel>>(
                                future: fireStoreUtils.getCuisines(),
                                initialData: const [],
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return Center(
                                      child: CircularProgressIndicator.adaptive(
                                        valueColor: AlwaysStoppedAnimation(
                                            Color(COLOR_PRIMARY)),
                                      ),
                                    );
                                  }

                                  if ((snapshot.hasData ||
                                          (snapshot.data?.isNotEmpty ??
                                              false)) &&
                                      mounted) {
                                    return Container(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        height: 100,
                                        child: ListView.builder(
                                          scrollDirection: Axis.horizontal,
                                          itemCount: snapshot.data!.length >= 15
                                              ? 15
                                              : snapshot.data!.length,
                                          itemBuilder: (context, index) {
                                            return buildCategoryItem(
                                                snapshot.data![index]);
                                          },
                                        ));
                                  } else {
                                    return showEmptyState(
                                        'No Categories'.tr(), context);
                                  }
                                }),
                          ),

                          buildTitleRow(
                            titleValue: "Food Varieties".tr(),
                            onClick: () {},
                            isViewAll: true,
                          ),
                          FoodVarietiesRow(),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              buildTitleRow(
                                titleValue: "Nearby Foods".tr(),
                                onClick: () {
                                  push(
                                    context,
                                    const ViewAllPopularFoodNearByScreen(),
                                  );
                                },
                              ),
                              SizedBox(
                                height: 120,
                                child: lstNearByFood.isEmpty
                                    ? showEmptyState(
                                        'No popular Item found'.tr(), context)
                                    : ListView.builder(
                                        scrollDirection: Axis.horizontal,
                                        itemCount: lstNearByFood.length >= 15
                                            ? 15
                                            : lstNearByFood.length,
                                        itemBuilder: (context, index) {
                                          VendorModel?
                                              popularNearFoodVendorModel;

                                          if (vendors.isNotEmpty) {
                                            for (int a = 0;
                                                a < vendors.length;
                                                a++) {
                                              if (vendors[a].id ==
                                                  lstNearByFood[index]
                                                      .vendorID) {
                                                popularNearFoodVendorModel =
                                                    vendors[a];
                                              }
                                            }
                                          }

                                          return popularNearFoodVendorModel ==
                                                  null
                                              ? Container()
                                              : popularFoodItem(
                                                  context,
                                                  lstNearByFood[index],
                                                  popularNearFoodVendorModel);
                                        }),
                              ),
                            ],
                          ),

                          // Order Again Section (hide when no previous orders)
                          if (MyAppState.currentUser != null &&
                              !isLoadingOrderAgain &&
                              orderAgainProducts.isNotEmpty)
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                buildTitleRow(
                                  titleValue: "Order Again".tr(),
                                  onClick: () {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            'Order Again feature coming soon!'),
                                        duration: Duration(seconds: 2),
                                      ),
                                    );
                                  },
                                ),
                                Container(
                                  width: MediaQuery.of(context).size.width,
                                  height: 220,
                                  margin:
                                      const EdgeInsets.fromLTRB(16, 0, 0, 10),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    physics: const BouncingScrollPhysics(),
                                    itemCount: orderAgainProducts.length >= 10
                                        ? 10
                                        : orderAgainProducts.length,
                                    itemBuilder: (context, index) {
                                      ProductModel product =
                                          orderAgainProducts[index];
                                      VendorModel? vendorModel;
                                      for (VendorModel vendor in vendors) {
                                        if (vendor.id == product.vendorID) {
                                          vendorModel = vendor;
                                          break;
                                        }
                                      }
                                      if (vendorModel == null) {
                                        return Container();
                                      }
                                      return _orderAgainCard(
                                          product, vendorModel);
                                    },
                                  ),
                                ),
                              ],
                            ),

                          // Meal for One • Sulit price Section
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              _mealForOneHeader(),
                              isLoadingMealForOne
                                  ? Container(
                                      height: 200,
                                      child: Center(
                                        child:
                                            CircularProgressIndicator.adaptive(
                                          valueColor: AlwaysStoppedAnimation(
                                              Color(COLOR_PRIMARY)),
                                        ),
                                      ),
                                    )
                                  : mealForOneProducts.isEmpty
                                      ? Container(
                                          height: 100,
                                          child: Center(
                                            child: Text(
                                              'No sulit meals found',
                                              style: TextStyle(
                                                color: Colors.grey.shade600,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ),
                                        )
                                      : Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: 220,
                                          margin: const EdgeInsets.fromLTRB(
                                              10, 0, 0, 10),
                                          child: ListView.builder(
                                            shrinkWrap: true,
                                            scrollDirection: Axis.horizontal,
                                            physics:
                                                const BouncingScrollPhysics(),
                                            itemCount:
                                                mealForOneProducts.length >= 10
                                                    ? 10
                                                    : mealForOneProducts.length,
                                            itemBuilder: (context, index) {
                                              ProductModel product =
                                                  mealForOneProducts[index];
                                              // Find the vendor for this product
                                              VendorModel? vendorModel;
                                              for (VendorModel vendor
                                                  in vendors) {
                                                if (vendor.id ==
                                                    product.vendorID) {
                                                  vendorModel = vendor;
                                                  break;
                                                }
                                              }
                                              if (vendorModel == null) {
                                                return Container(); // Skip if vendor not found
                                              }
                                              return _mealForOneCard(
                                                  product, vendorModel);
                                            },
                                          ),
                                        ),
                            ],
                          ),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              buildTitleRow(
                                titleValue: "Nearby Restaurants".tr(),
                                titleIcon: Icons.restaurant_rounded,
                                onClick: () {
                                  push(
                                    context,
                                    const ViewAllNewArrivalRestaurantScreen(),
                                  );
                                },
                              ),
                              StreamBuilder<List<VendorModel>>(
                                  stream: fireStoreUtils
                                      .getVendorsForNewArrival()
                                      .asBroadcastStream(),
                                  initialData: const [],
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState ==
                                        ConnectionState.waiting) {
                                      return Center(
                                        child:
                                            CircularProgressIndicator.adaptive(
                                          valueColor: AlwaysStoppedAnimation(
                                              Color(COLOR_PRIMARY)),
                                        ),
                                      );
                                    }

                                    if ((snapshot.hasData ||
                                            (snapshot.data?.isNotEmpty ??
                                                false)) &&
                                        mounted) {
                                      newArrivalLst = snapshot.data!;

                                      return newArrivalLst.isEmpty
                                          ? showEmptyState(
                                              'No Vendors'.tr(), context)
                                          : Container(
                                              width: MediaQuery.of(context)
                                                  .size
                                                  .width,
                                              height: 260,
                                              margin: const EdgeInsets.fromLTRB(
                                                  10, 0, 0, 10),
                                              child: ListView.builder(
                                                  shrinkWrap: true,
                                                  scrollDirection:
                                                      Axis.horizontal,
                                                  physics:
                                                      const BouncingScrollPhysics(),
                                                  itemCount:
                                                      newArrivalLst.length >= 15
                                                          ? 15
                                                          : newArrivalLst
                                                              .length,
                                                  itemBuilder: (context,
                                                          index) =>
                                                      buildNewArrivalItem(
                                                          newArrivalLst[
                                                              index])));
                                    } else {
                                      return showEmptyState(
                                          'No Vendors'.tr(), context);
                                    }
                                  }),
                            ],
                          ),

                          buildTitleRow(
                            titleValue: "View Promo".tr(),
                            onClick: () {
                              push(
                                context,
                                OffersScreen(
                                  vendors: vendors,
                                ),
                              );
                            },
                          ),

                          offerVendorList.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CarouselSlider(
                                      items: [
                                        Container(
                                          width: double.infinity,
                                          child: SizedBox.expand(
                                            child: Image.asset(
                                              'assets/slides/1.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: double.infinity,
                                          child: SizedBox.expand(
                                            child: Image.asset(
                                              'assets/slides/2.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: double.infinity,
                                          child: SizedBox.expand(
                                            child: Image.asset(
                                              'assets/slides/3.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: double.infinity,
                                          child: SizedBox.expand(
                                            child: Image.asset(
                                              'assets/slides/4.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ],
                                      options: CarouselOptions(
                                        height: 170, // Adjust height as needed
                                        viewportFraction: 1.0,
                                        autoPlay: true,
                                        enlargeCenterPage: false,
                                        aspectRatio: 16 / 9,
                                        enableInfiniteScroll: true,
                                        pauseAutoPlayOnTouch: true,
                                      ),
                                    ),
                                  ),
                                )
                              : Container(
                                  width: MediaQuery.of(context).size.width,
                                  height: 300,
                                  margin:
                                      const EdgeInsets.fromLTRB(10, 0, 0, 10),
                                  child: ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.horizontal,
                                      physics: const BouncingScrollPhysics(),
                                      itemCount: offerVendorList.length >= 15
                                          ? 15
                                          : offerVendorList.length,
                                      itemBuilder: (context, index) {
                                        return buildCouponsForYouItem(
                                            context,
                                            offerVendorList[index],
                                            offersList[index]);
                                      })),

                          Column(
                            children: [
                              buildTitleRow(
                                titleValue: "Top Restaurants".tr(),
                                onClick: () {
                                  push(
                                    context,
                                    const ViewAllPopularRestaurantScreen(),
                                  );
                                },
                              ),
                              popularRestaurantLst.isEmpty
                                  ? showEmptyState(
                                      'No Popular restaurant'.tr(), context)
                                  : Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: 130,
                                      margin: const EdgeInsets.fromLTRB(
                                          10, 0, 0, 10),
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        scrollDirection: Axis.horizontal,
                                        physics: const BouncingScrollPhysics(),
                                        itemCount: popularRestaurantLst
                                                    .toSet()
                                                    .toList()
                                                    .length >=
                                                5
                                            ? 5
                                            : popularRestaurantLst
                                                .toSet()
                                                .toList()
                                                .length,
                                        itemBuilder: (context, index) {
                                          List uniqueRestaurants =
                                              popularRestaurantLst
                                                  .toSet()
                                                  .toList();
                                          return GestureDetector(
                                            onTap: () => push(
                                              context,
                                              NewVendorProductsScreen(
                                                  vendorModel:
                                                      uniqueRestaurants[index]),
                                            ),
                                            child: Container(
                                              width: 120,
                                              margin: const EdgeInsets.only(
                                                  right: 12, bottom: 8),
                                              decoration: BoxDecoration(
                                                color: isDarkMode(context)
                                                    ? Color(DARK_CARD_BG_COLOR)
                                                    : Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(0.06),
                                                    blurRadius: 8,
                                                    offset: const Offset(0, 2),
                                                  ),
                                                ],
                                                border: Border.all(
                                                  color: isDarkMode(context)
                                                      ? Color(
                                                          DarkContainerBorderColor)
                                                      : Colors.grey.shade200,
                                                  width: 1,
                                                ),
                                              ),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    // Vendor logo
                                                    Container(
                                                      width: 70,
                                                      height: 70,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(12),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.1),
                                                            blurRadius: 8,
                                                            offset:
                                                                const Offset(
                                                                    0, 2),
                                                          ),
                                                        ],
                                                      ),
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(12),
                                                        child:
                                                            CachedNetworkImage(
                                                          imageUrl:
                                                              getImageVAlidUrl(
                                                                  uniqueRestaurants[
                                                                          index]
                                                                      .photo),
                                                          fit: BoxFit.cover,
                                                          placeholder:
                                                              (context, url) =>
                                                                  Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color: Colors.grey
                                                                  .shade200,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          12),
                                                            ),
                                                            child: const Center(
                                                              child: Icon(
                                                                Icons
                                                                    .restaurant,
                                                                size: 30,
                                                                color:
                                                                    Colors.grey,
                                                              ),
                                                            ),
                                                          ),
                                                          errorWidget: (context,
                                                                  url, error) =>
                                                              Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color: Colors.grey
                                                                  .shade200,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          12),
                                                            ),
                                                            child: const Center(
                                                              child: Icon(
                                                                Icons
                                                                    .restaurant,
                                                                size: 30,
                                                                color:
                                                                    Colors.grey,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(height: 6),
                                                    // Vendor title
                                                    Text(
                                                      uniqueRestaurants[index]
                                                          .title,
                                                      style: TextStyle(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 12,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color:
                                                            isDarkMode(context)
                                                                ? Colors.white
                                                                : Colors
                                                                    .black87,
                                                      ),
                                                      maxLines: 1,
                                                      textAlign:
                                                          TextAlign.center,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                    const SizedBox(height: 2),
                                                    // Address/location
                                                    Text(
                                                      uniqueRestaurants[index]
                                                              .location
                                                              .isNotEmpty
                                                          ? uniqueRestaurants[
                                                                  index]
                                                              .location
                                                          : uniqueRestaurants[
                                                                      index]
                                                                  .subTitle ??
                                                              'No address available',
                                                      style: TextStyle(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color:
                                                            isDarkMode(context)
                                                                ? Colors.white70
                                                                : Colors.grey
                                                                    .shade600,
                                                      ),
                                                      maxLines: 1,
                                                      textAlign:
                                                          TextAlign.center,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                            ],
                          ),

                          ListView.builder(
                            itemCount: categoryWiseProductList.length,
                            shrinkWrap: true,
                            physics: const BouncingScrollPhysics(),
                            padding: EdgeInsets.zero,
                            itemBuilder: (context, index) {
                              return StreamBuilder<List<VendorModel>>(
                                stream: FireStoreUtils().getCategoryRestaurants(
                                    categoryWiseProductList[index]
                                        .id
                                        .toString()),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return Center(
                                      child: CircularProgressIndicator.adaptive(
                                        valueColor: AlwaysStoppedAnimation(
                                            Color(COLOR_PRIMARY)),
                                      ),
                                    );
                                  }

                                  if ((snapshot.hasData ||
                                          (snapshot.data?.isNotEmpty ??
                                              false)) &&
                                      mounted) {
                                    return snapshot.data!.isEmpty
                                        ? Container()
                                        : Column(
                                            children: [
                                              buildTitleRow(
                                                titleValue:
                                                    categoryWiseProductList[
                                                            index]
                                                        .title
                                                        .toString(),
                                                onClick: () {
                                                  push(
                                                    context,
                                                    ViewAllCategoryProductScreen(
                                                      vendorCategoryModel:
                                                          categoryWiseProductList[
                                                              index],
                                                    ),
                                                  );
                                                },
                                                isViewAll: false,
                                              ),
                                              SizedBox(
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  height: MediaQuery.of(context)
                                                          .size
                                                          .height *
                                                      0.28,
                                                  child: Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 10),
                                                    child: ListView.builder(
                                                      shrinkWrap: true,
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      physics:
                                                          const BouncingScrollPhysics(),
                                                      padding: EdgeInsets.zero,
                                                      itemCount:
                                                          snapshot.data!.length,
                                                      itemBuilder:
                                                          (context, index) {
                                                        VendorModel
                                                            vendorModel =
                                                            snapshot
                                                                .data![index];

                                                        double
                                                            distanceInMeters =
                                                            Geolocator.distanceBetween(
                                                                vendorModel
                                                                    .latitude,
                                                                vendorModel
                                                                    .longitude,
                                                                MyAppState
                                                                    .selectedPosotion
                                                                    .location!
                                                                    .latitude,
                                                                MyAppState
                                                                    .selectedPosotion
                                                                    .location!
                                                                    .longitude);

                                                        double kilometer =
                                                            distanceInMeters /
                                                                1000;

                                                        double minutes = 1.2;

                                                        double value =
                                                            minutes * kilometer;

                                                        final int hour =
                                                            value ~/ 60;

                                                        final double minute =
                                                            value % 60;

                                                        return Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                                  horizontal: 8,
                                                                  vertical: 6),
                                                          child:
                                                              GestureDetector(
                                                            onTap: () async {
                                                              push(
                                                                context,
                                                                NewVendorProductsScreen(
                                                                    vendorModel:
                                                                        vendorModel),
                                                              );
                                                            },
                                                            child: SizedBox(
                                                              width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.7,
                                                              child: Container(
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              24),
                                                                  gradient:
                                                                      LinearGradient(
                                                                    begin: Alignment
                                                                        .topLeft,
                                                                    end: Alignment
                                                                        .bottomRight,
                                                                    colors:
                                                                        isDarkMode(context)
                                                                            ? [
                                                                                const Color(0xFF2C2C2C),
                                                                                const Color(0xFF1A1A1A),
                                                                              ]
                                                                            : [
                                                                                Colors.white,
                                                                                const Color(0xFFF8F9FA),
                                                                              ],
                                                                  ),
                                                                  border: Border.all(
                                                                      color: isDarkMode(
                                                                              context)
                                                                          ? Colors
                                                                              .grey
                                                                              .shade800
                                                                          : Colors
                                                                              .grey
                                                                              .shade100,
                                                                      width:
                                                                          1.5),
                                                                  boxShadow: [
                                                                    BoxShadow(
                                                                      color: isDarkMode(context)
                                                                          ? Colors.black.withOpacity(
                                                                              0.2)
                                                                          : Colors
                                                                              .black
                                                                              .withOpacity(0.08),
                                                                      blurRadius:
                                                                          20,
                                                                      offset:
                                                                          const Offset(
                                                                              0,
                                                                              8),
                                                                      spreadRadius:
                                                                          0,
                                                                    ),
                                                                    BoxShadow(
                                                                      color: isDarkMode(context)
                                                                          ? Colors.black.withOpacity(
                                                                              0.1)
                                                                          : Colors
                                                                              .white
                                                                              .withOpacity(0.8),
                                                                      blurRadius:
                                                                          1,
                                                                      offset:
                                                                          const Offset(
                                                                              0,
                                                                              1),
                                                                      spreadRadius:
                                                                          0,
                                                                    ),
                                                                  ],
                                                                ),
                                                                child: Stack(
                                                                  children: [
                                                                    Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Expanded(
                                                                            child:
                                                                                Stack(
                                                                          children: [
                                                                            CachedNetworkImage(
                                                                              imageUrl: getStableRandomProductImage(vendorModel),
                                                                              imageBuilder: (context, imageProvider) => Container(
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                                                                                  image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
                                                                                ),
                                                                              ),
                                                                              placeholder: (context, url) => Container(
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                                                                                  gradient: LinearGradient(
                                                                                    begin: Alignment.topLeft,
                                                                                    end: Alignment.bottomRight,
                                                                                    colors: [
                                                                                      Color(COLOR_PRIMARY).withOpacity(0.1),
                                                                                      Color(COLOR_PRIMARY).withOpacity(0.05),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                                child: Center(
                                                                                  child: CircularProgressIndicator.adaptive(
                                                                                    valueColor: AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              errorWidget: (context, url, error) => Container(
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                                                                                  color: Colors.grey.shade200,
                                                                                ),
                                                                                child: Center(
                                                                                  child: Icon(
                                                                                    Icons.restaurant,
                                                                                    size: 40,
                                                                                    color: Colors.grey.shade400,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                            // Vendor logo badge overlay
                                                                            Positioned(
                                                                              top: 12,
                                                                              right: 12,
                                                                              child: Container(
                                                                                width: 40,
                                                                                height: 40,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.white,
                                                                                  borderRadius: BorderRadius.circular(20),
                                                                                  boxShadow: [
                                                                                    BoxShadow(
                                                                                      color: Colors.black.withOpacity(0.2),
                                                                                      blurRadius: 8,
                                                                                      offset: const Offset(0, 2),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                child: ClipRRect(
                                                                                  borderRadius: BorderRadius.circular(20),
                                                                                  child: CachedNetworkImage(
                                                                                    imageUrl: getImageVAlidUrl(vendorModel.photo),
                                                                                    fit: BoxFit.cover,
                                                                                    placeholder: (context, url) => const Center(
                                                                                      child: Icon(
                                                                                        Icons.restaurant,
                                                                                        size: 20,
                                                                                        color: Colors.grey,
                                                                                      ),
                                                                                    ),
                                                                                    errorWidget: (context, url, error) => const Center(
                                                                                      child: Icon(
                                                                                        Icons.restaurant,
                                                                                        size: 20,
                                                                                        color: Colors.grey,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Positioned(
                                                                              bottom: 12,
                                                                              right: 12,
                                                                              child: Container(
                                                                                decoration: BoxDecoration(
                                                                                  gradient: LinearGradient(
                                                                                    colors: [
                                                                                      Colors.amber.shade400,
                                                                                      Colors.amber.shade600,
                                                                                    ],
                                                                                  ),
                                                                                  borderRadius: BorderRadius.circular(8),
                                                                                  boxShadow: [
                                                                                    BoxShadow(
                                                                                      color: Colors.amber.withOpacity(0.3),
                                                                                      blurRadius: 6,
                                                                                      offset: const Offset(0, 2),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                                                                  child: Row(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    children: [
                                                                                      Text(vendorModel.reviewsCount != 0 ? (vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1) : 0.toString(),
                                                                                          style: const TextStyle(
                                                                                            fontFamily: "Poppins",
                                                                                            letterSpacing: 0.5,
                                                                                            fontSize: 13,
                                                                                            fontWeight: FontWeight.w700,
                                                                                            color: Colors.white,
                                                                                          )),
                                                                                      const SizedBox(width: 4),
                                                                                      const Icon(
                                                                                        Icons.star_rounded,
                                                                                        size: 16,
                                                                                        color: Colors.white,
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        )),
                                                                        const SizedBox(
                                                                            height:
                                                                                8),
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .symmetric(
                                                                              horizontal: 12),
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            children: [
                                                                              Text(vendorModel.title, maxLines: 1, style: TextStyle(fontFamily: "Poppins", fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: 0.2, color: isDarkMode(context) ? Colors.white : Colors.black87)).tr(),
                                                                              const SizedBox(
                                                                                height: 8,
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  Container(
                                                                                    padding: const EdgeInsets.all(4),
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(COLOR_PRIMARY).withOpacity(0.1),
                                                                                      borderRadius: BorderRadius.circular(6),
                                                                                    ),
                                                                                    child: Icon(
                                                                                      Icons.location_on_rounded,
                                                                                      color: Color(COLOR_PRIMARY),
                                                                                      size: 16,
                                                                                    ),
                                                                                  ),
                                                                                  SizedBox(width: 8),
                                                                                  Expanded(
                                                                                    child: Text(vendorModel.location, maxLines: 1, style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: isDarkMode(context) ? Colors.white70 : Colors.grey.shade600)).tr(),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 8,
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  Container(
                                                                                    padding: const EdgeInsets.all(4),
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(COLOR_PRIMARY).withOpacity(0.1),
                                                                                      borderRadius: BorderRadius.circular(6),
                                                                                    ),
                                                                                    child: Icon(
                                                                                      Icons.access_time_rounded,
                                                                                      color: Color(COLOR_PRIMARY),
                                                                                      size: 16,
                                                                                    ),
                                                                                  ),
                                                                                  SizedBox(
                                                                                    width: 8,
                                                                                  ),
                                                                                  Text(
                                                                                    '${hour.toString().padLeft(2, "0")}h ${minute.toStringAsFixed(0).padLeft(2, "0")}m',
                                                                                    style: TextStyle(fontFamily: "Poppins", fontSize: 13, fontWeight: FontWeight.w600, color: isDarkMode(context) ? Colors.white70 : Colors.grey.shade700),
                                                                                  ),
                                                                                  SizedBox(
                                                                                    width: 12,
                                                                                  ),
                                                                                  Container(
                                                                                    padding: const EdgeInsets.all(4),
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(COLOR_PRIMARY).withOpacity(0.1),
                                                                                      borderRadius: BorderRadius.circular(6),
                                                                                    ),
                                                                                    child: Icon(
                                                                                      Icons.directions_car_rounded,
                                                                                      color: Color(COLOR_PRIMARY),
                                                                                      size: 16,
                                                                                    ),
                                                                                  ),
                                                                                  SizedBox(
                                                                                    width: 8,
                                                                                  ),
                                                                                  Text(
                                                                                    "${kilometer.toDouble().toStringAsFixed(currencyModel!.decimal)} km",
                                                                                    style: TextStyle(fontFamily: "Poppins", fontSize: 13, fontWeight: FontWeight.w600, color: isDarkMode(context) ? Colors.white70 : Colors.grey.shade700),
                                                                                  ).tr(),
                                                                                ],
                                                                              ),
                                                                              SizedBox(
                                                                                height: 12,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    // Overlay for closed restaurants
                                                                    if (!isRestaurantOpen(
                                                                        vendorModel))
                                                                      Positioned
                                                                          .fill(
                                                                        child:
                                                                            Container(
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(24),
                                                                            color:
                                                                                Colors.black.withOpacity(0.6),
                                                                          ),
                                                                          child:
                                                                              Center(
                                                                            child:
                                                                                Text(
                                                                              'Temporarily Closed'.tr(),
                                                                              style: TextStyle(
                                                                                fontFamily: "Poppinsm",
                                                                                fontSize: 16,
                                                                                fontWeight: FontWeight.w600,
                                                                                color: Colors.white,
                                                                                letterSpacing: 0.5,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    ),
                                                  )),
                                            ],
                                          );
                                  } else {
                                    return Container();
                                  }
                                },
                              );
                            },
                          ),

                          buildTitleRow(
                            titleValue: "All Restaurants".tr(),
                            onClick: () {},
                            isViewAll: true,
                          ),

                          vendors.isEmpty
                              ? showEmptyState('No Vendors'.tr(), context)
                              : Container(
                                  width: MediaQuery.of(context).size.width,
                                  margin:
                                      const EdgeInsets.fromLTRB(10, 0, 0, 10),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.vertical,
                                    physics: const BouncingScrollPhysics(),
                                    itemCount: vendors.length,
                                    itemBuilder: (context, index) {
                                      VendorModel vendorModel = vendors[index];

                                      return buildAllRestaurantsData(
                                          vendorModel);
                                    },
                                  ),
                                ),

                          // Removed "See All restaurant around you" button as requested
                          if (recommendedProducts.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Recommended for You',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  GridView.builder(
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2, // Two columns
                                      mainAxisSpacing: 5,
                                      crossAxisSpacing: 5,
                                      childAspectRatio:
                                          0.7, // Adjusted to allow more vertical space
                                    ),
                                    itemCount: recommendedProducts.length,
                                    itemBuilder: (context, index) {
                                      final product =
                                          recommendedProducts[index];
                                      final vendor = vendors.firstWhere(
                                        (v) => v.id == product.vendorID,
                                        orElse: () => VendorModel(
                                            title: 'Unknown Vendor'),
                                      );
                                      return buildProductItem(product, vendor);
                                    },
                                  ),
                                ],
                              ),
                            )
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: const CurrentOrdersBanner(),
                  )
                ]),
    ));
  }

  final StoryController controller = StoryController();

  Widget storyWidget() {
    // if stories are disabled in remote config, hide entirely
    if (storyEnable != true) return SizedBox.shrink();

    return Container(
      height: 200,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stories Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(COLOR_PRIMARY),
                        Color(COLOR_PRIMARY).withOpacity(0.8),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Color(COLOR_PRIMARY).withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.play_circle_filled,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  "Stories",
                  style: TextStyle(
                    fontFamily: "Poppinsm",
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: isDarkMode(context) ? Colors.white : Colors.black87,
                  ),
                ),
                const Spacer(),
                Text(
                  "Tap to watch",
                  style: TextStyle(
                    fontFamily: "Poppinsm",
                    fontSize: 12,
                    color: isDarkMode(context)
                        ? Colors.white70
                        : Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          // Stories List
          Expanded(
            child: FutureBuilder<List<StoryModel>>(
              future: FireStoreUtils().getStory(),
              builder: (context, snapshot) {
                // 1) Loading state: show 3 placeholder cards
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 3,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemBuilder: (_, i) => Container(
                      width: 140,
                      margin: const EdgeInsets.only(right: 16),
                      child: Card(
                        elevation: 8,
                        shadowColor: Colors.black.withOpacity(0.2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(COLOR_PRIMARY).withOpacity(0.1),
                                Color(COLOR_PRIMARY).withOpacity(0.05),
                              ],
                            ),
                          ),
                          child: Center(
                            child: CircularProgressIndicator.adaptive(
                              valueColor:
                                  AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }

                // 2) Error or empty: show empty state
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.video_library_outlined,
                            size: 48,
                            color: isDarkMode(context)
                                ? Colors.white54
                                : Colors.grey.shade400,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "No stories available",
                            style: TextStyle(
                              fontFamily: "Poppinsm",
                              fontSize: 14,
                              color: isDarkMode(context)
                                  ? Colors.white70
                                  : Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                // 3) Data arrived: build your normal list
                final stories = snapshot.data!;
                return ListView.builder(
                  itemCount: stories.length,
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemBuilder: (context, index) {
                    final story = stories[index];
                    return Container(
                      width: 140,
                      margin: const EdgeInsets.only(right: 16),
                      child: InkWell(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                MoreStories(storyList: stories, index: index),
                          ),
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.15),
                                blurRadius: 15,
                                offset: const Offset(0, 8),
                                spreadRadius: 0,
                              ),
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 30,
                                offset: const Offset(0, 16),
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(
                              children: [
                                // Story Image
                                CachedNetworkImage(
                                  imageUrl: story.videoThumbnail.toString(),
                                  width: double.infinity,
                                  height: double.infinity,
                                  fit: BoxFit.cover,
                                  placeholder: (context, url) => Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          Color(COLOR_PRIMARY).withOpacity(0.1),
                                          Color(COLOR_PRIMARY)
                                              .withOpacity(0.05),
                                        ],
                                      ),
                                    ),
                                    child: Center(
                                      child: CircularProgressIndicator.adaptive(
                                        valueColor: AlwaysStoppedAnimation(
                                            Color(COLOR_PRIMARY)),
                                      ),
                                    ),
                                  ),
                                  errorWidget: (context, url, error) =>
                                      Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          Colors.grey.shade200,
                                          Colors.grey.shade100,
                                        ],
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.video_library,
                                      size: 40,
                                      color: Colors.grey.shade400,
                                    ),
                                  ),
                                ),
                                // Gradient overlay
                                Positioned.fill(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Colors.transparent,
                                          Colors.black.withOpacity(0.6),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                // Play button
                                Positioned(
                                  top: 12,
                                  right: 12,
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.9),
                                      borderRadius: BorderRadius.circular(12),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.2),
                                          blurRadius: 6,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      Icons.play_arrow,
                                      size: 16,
                                      color: Color(COLOR_PRIMARY),
                                    ),
                                  ),
                                ),
                                // "NEW" badge for recent stories
                                if (DateTime.now()
                                        .difference(story.createdAt!.toDate())
                                        .inDays <
                                    1)
                                  Positioned(
                                    top: 12,
                                    left: 12,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            Colors.red.shade400,
                                            Colors.red.shade600,
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.red.withOpacity(0.3),
                                            blurRadius: 4,
                                            offset: const Offset(0, 1),
                                          ),
                                        ],
                                      ),
                                      child: Text(
                                        'NEW',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 8,
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: 0.3,
                                        ),
                                      ),
                                    ),
                                  ),
                                // Vendor name overlay
                                FutureBuilder<VendorModel>(
                                  future: FireStoreUtils().getVendorByVendorID(
                                      story.vendorID.toString()),
                                  builder: (c, snap) {
                                    if (snap.connectionState ==
                                        ConnectionState.waiting)
                                      return SizedBox.shrink();
                                    if (!snap.hasData) return SizedBox.shrink();
                                    return Positioned(
                                      bottom: 12,
                                      left: 12,
                                      right: 12,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            snap.data!.title,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 12,
                                              shadows: [
                                                Shadow(
                                                  offset: Offset(0, 1),
                                                  blurRadius: 3,
                                                  color: Colors.black,
                                                ),
                                              ],
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            "Tap to watch",
                                            style: TextStyle(
                                              color:
                                                  Colors.white.withOpacity(0.8),
                                              fontSize: 9,
                                              fontWeight: FontWeight.w500,
                                              shadows: [
                                                Shadow(
                                                  offset: Offset(0, 1),
                                                  blurRadius: 2,
                                                  color: Colors.black,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildVendorItemData(
    BuildContext context,
    ProductModel product,
  ) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      width: MediaQuery.of(context).size.width * 0.8,
      margin: const EdgeInsets.fromLTRB(10, 10, 10, 0),
      padding: const EdgeInsets.all(5),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: CachedNetworkImage(
              imageUrl: getImageVAlidUrl(product.photo),
              height: 100,
              width: 100,
              memCacheHeight: 100,
              memCacheWidth: 100,
              imageBuilder: (context, imageProvider) => Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image:
                      DecorationImage(image: imageProvider, fit: BoxFit.cover),
                ),
              ),
              placeholder: (context, url) => Center(
                  child: CircularProgressIndicator.adaptive(
                valueColor: AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
              )),
              errorWidget: (context, url, error) => ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  AppGlobal.placeHolderImage!,
                ),
              ),
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 10,
                ),
                Text(
                  product.name,
                  style: const TextStyle(
                    fontFamily: "Poppinsm",
                    fontSize: 18,
                    color: Color(0xff000000),
                  ),
                  maxLines: 1,
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  product.description,
                  maxLines: 1,
                  style: const TextStyle(
                    fontFamily: "Poppinsm",
                    fontSize: 16,
                    color: Color(0xff9091A4),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  "${amountShow(amount: product.price)}",
                  style: TextStyle(
                    fontFamily: "Poppinsm",
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(COLOR_PRIMARY),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget popularFoodItem(
    BuildContext context,
    ProductModel product,
    VendorModel popularNearFoodVendorModel,
  ) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () async {
        VendorModel? vendorModel =
            await FireStoreUtils.getVendor(product.vendorID);

        if (vendorModel != null) {
          push(
            context,
            ProductDetailsScreen(
              vendorModel: vendorModel,
              productModel: product,
            ),
          );
        }
      },
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDarkMode(context)
                ? [
                    const Color(0xFF2C2C2C),
                    const Color(0xFF1A1A1A),
                  ]
                : [
                    Colors.white,
                    const Color(0xFFF8F9FA),
                  ],
          ),
          boxShadow: [
            BoxShadow(
              color: isDarkMode(context)
                  ? Colors.black.withOpacity(0.3)
                  : Colors.grey.withOpacity(0.15),
              blurRadius: 15,
              offset: const Offset(0, 6),
              spreadRadius: 0,
            ),
            BoxShadow(
              color: isDarkMode(context)
                  ? Colors.black.withOpacity(0.1)
                  : Colors.grey.withOpacity(0.05),
              blurRadius: 30,
              offset: const Offset(0, 12),
              spreadRadius: 0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              // Product Image with badges
              Stack(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: CachedNetworkImage(
                        imageUrl: getImageVAlidUrl(product.photo),
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(COLOR_PRIMARY).withOpacity(0.1),
                                Color(COLOR_PRIMARY).withOpacity(0.05),
                              ],
                            ),
                          ),
                          child: Center(
                            child: CircularProgressIndicator.adaptive(
                              valueColor:
                                  AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                            ),
                          ),
                        ),
                        errorWidget: (context, url, error) => Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.grey.shade200,
                          ),
                          child: Icon(
                            Icons.fastfood,
                            size: 30,
                            color: Colors.grey.shade400,
                          ),
                        ),
                      ),
                    ),
                  ),
                  // "TOP SELLING" badge
                  Positioned(
                    top: 6,
                    left: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.green.shade400,
                            Colors.green.shade600,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(6),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.green.withOpacity(0.3),
                            blurRadius: 4,
                            offset: const Offset(0, 1),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.trending_up,
                            size: 8,
                            color: Colors.white,
                          ),
                          const SizedBox(width: 1),
                          Text(
                            'TOP',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 7,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Discount badge (if applicable)
                  if (product.disPrice != "" && product.disPrice != "0")
                    Positioned(
                      top: 6,
                      right: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 2),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.red.shade400,
                              Colors.red.shade600,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(4),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.red.withOpacity(0.3),
                              blurRadius: 3,
                              offset: const Offset(0, 1),
                            ),
                          ],
                        ),
                        child: Text(
                          'SALE',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 6,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              // Product Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Product name
                    Text(
                      product.name,
                      style: TextStyle(
                        fontFamily: "Poppinsm",
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color:
                            isDarkMode(context) ? Colors.white : Colors.black87,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    // Product description
                    Text(
                      product.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: "Poppinsm",
                        fontSize: 11,
                        color: isDarkMode(context)
                            ? Colors.white70
                            : Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(height: 6),
                    // Restaurant name
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Color(COLOR_PRIMARY).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        popularNearFoodVendorModel.title,
                        style: TextStyle(
                          fontFamily: "Poppinsm",
                          fontSize: 9,
                          fontWeight: FontWeight.w600,
                          color: Color(COLOR_PRIMARY),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(height: 6),
                    // Price section
                    Row(
                      children: [
                        // Current price
                        Text(
                          product.disPrice == "" || product.disPrice == "0"
                              ? amountShow(amount: product.price)
                              : amountShow(amount: product.disPrice),
                          style: TextStyle(
                            fontFamily: "Poppinsm",
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Color(COLOR_PRIMARY),
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Original price (if discounted)
                        if (product.disPrice != "" && product.disPrice != "0")
                          Text(
                            amountShow(amount: product.price),
                            style: TextStyle(
                              fontFamily: "Poppinsm",
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: Colors.grey.shade500,
                              decoration: TextDecoration.lineThrough,
                            ),
                          ),
                        const Spacer(),
                        // Add to cart button
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Color(COLOR_PRIMARY),
                                Color(COLOR_PRIMARY).withOpacity(0.8),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(
                                color: Color(COLOR_PRIMARY).withOpacity(0.3),
                                blurRadius: 4,
                                offset: const Offset(0, 1),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.add_shopping_cart,
                                size: 12,
                                color: Colors.white,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                'Add',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildAllRestaurantsData(VendorModel vendorModel) {
    debugPrint(vendorModel.photo);
    bool restaurantIsOpen = isRestaurantOpen(vendorModel);

    List<OfferModel> tempList = [];

    List<double> discountAmountTempList = [];

    offerList.forEach((element) {
      if (vendorModel.id == element.restaurantId &&
          element.expireOfferDate!.toDate().isAfter(DateTime.now())) {
        tempList.add(element);

        discountAmountTempList.add(double.parse(element.discount.toString()));
      }
    });

    // Choose a random product image from this vendor (excluding placeholder/empty), fallback to vendor photo
    List<ProductModel> vendorProducts =
        allProducts.where((p) => p.vendorID == vendorModel.id).toList();
    List<ProductModel> validVendorProducts = vendorProducts.where((p) {
      final String photo = p.photo.trim();
      if (photo.isEmpty) return false;
      if (AppGlobal.placeHolderImage != null &&
          photo == AppGlobal.placeHolderImage) return false;
      return true;
    }).toList();

    String cardImage = vendorModel.photo;
    if (validVendorProducts.isNotEmpty) {
      final seededRandom = Random(vendorModel.id.hashCode);
      final ProductModel randomProduct =
          validVendorProducts[seededRandom.nextInt(validVendorProducts.length)];
      cardImage = randomProduct.photo;
    }

    return GestureDetector(
      onTap: () => push(
        context,
        NewVendorProductsScreen(vendorModel: vendorModel),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isDarkMode(context)
                  ? const Color(DarkContainerBorderColor)
                  : Colors.grey.shade100,
              width: 1),
          color: isDarkMode(context)
              ? const Color(DarkContainerColor)
              : Colors.white,
          boxShadow: [
            isDarkMode(context)
                ? const BoxShadow()
                : BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 5,
                  ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: CachedNetworkImage(
                        imageUrl: getImageVAlidUrl(cardImage),
                        width: MediaQuery.of(context).size.width,
                        height: 180,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Center(
                            child: CircularProgressIndicator.adaptive(
                          valueColor:
                              AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                        )),
                        errorWidget: (context, url, error) => ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Image.network(
                              AppGlobal.placeHolderImage!,
                              width: MediaQuery.of(context).size.width,
                              height: 180,
                              fit: BoxFit.cover,
                            )),
                      ),
                    ),
                    if (discountAmountTempList.isNotEmpty)
                      Positioned(
                        top: 10,
                        left: 10,
                        child: Container(
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(
                                      'assets/images/offer_badge.png'))),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              discountAmountTempList
                                      .reduce(min)
                                      .toStringAsFixed(currencyModel!.decimal) +
                                  "% OFF".tr(),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    Positioned(
                      bottom: 10,
                      right: 10,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 2),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                  vendorModel.reviewsCount != 0
                                      ? (vendorModel.reviewsSum /
                                              vendorModel.reviewsCount)
                                          .toStringAsFixed(1)
                                      : 0.toString(),
                                  style: const TextStyle(
                                    fontFamily: "Poppinsm",
                                    letterSpacing: 0.5,
                                    fontSize: 12,
                                    color: Colors.white,
                                  )),
                              const SizedBox(width: 3),
                              const Icon(
                                Icons.star,
                                size: 16,
                                color: Colors.white,
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(vendorModel.title,
                          maxLines: 1,
                          style: TextStyle(
                            fontFamily: "Poppinsm",
                            letterSpacing: 0.5,
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: isDarkMode(context)
                                ? Colors.white
                                : Colors.black,
                          )).tr(),
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ImageIcon(
                            const AssetImage('assets/images/location3x.png'),
                            size: 15,
                            color: Color(COLOR_PRIMARY),
                          ),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              vendorModel.location,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: "Poppinsm",
                                letterSpacing: 0.5,
                                color: isDarkMode(context)
                                    ? Colors.white70
                                    : const Color(0xff555353),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.star,
                              size: 20,
                              color: Color(COLOR_PRIMARY),
                            ),
                            const SizedBox(width: 3),
                            Text(
                                vendorModel.reviewsCount != 0
                                    ? '${(vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1)}'
                                    : 0.toString(),
                                style: TextStyle(
                                  fontFamily: "Poppinsm",
                                  letterSpacing: 0.5,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : const Color(0xff000000),
                                )),
                            const SizedBox(width: 3),
                            Text(
                                '(${vendorModel.reviewsCount.toStringAsFixed(1)})',
                                style: TextStyle(
                                  fontFamily: "Poppinsm",
                                  letterSpacing: 0.5,
                                  color: isDarkMode(context)
                                      ? Colors.white60
                                      : const Color(0xff666666),
                                )),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
            // Overlay for closed restaurants
            if (!restaurantIsOpen)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.black.withOpacity(0.6),
                  ),
                  child: Center(
                    child: Text(
                      'Temporarily Closed'.tr(),
                      style: TextStyle(
                        fontFamily: "Poppinsm",
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget buildProductItem(ProductModel product, VendorModel vendor) {
    return Material(
      color: Colors.transparent,
      child: GestureDetector(
        onTap: () {
          // Navigate to ProductDetailsScreen with required arguments
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProductDetailsScreen(
                productModel: product, // Pass product
                vendorModel: vendor, // Pass vendor
              ),
            ),
          );
          print("Tapped on product: ${product.name}");
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.grey.shade200,
              width: 1,
            ),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                blurRadius: 5,
              ),
            ],
          ),
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Product Image
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.network(
                  product.photo,
                  width: double.infinity,
                  height: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      const Icon(Icons.error),
                ),
              ),
              const SizedBox(height: 10),
              // Product Name
              Text(
                product.name,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 5),
              // Product Price
              Text(
                "\u20B1${product.price}", // Display price with peso sign
                style: TextStyle(
                  color: Theme.of(context)
                      .primaryColor, // Use the app's primary color
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),
              // Vendor Name
              Text(
                vendor.title,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  buildCategoryItem(VendorCategoryModel model) {
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: GestureDetector(
        onTap: () {
          push(
            context,
            CategoryDetailsScreen(
              category: model,
              isDineIn: false,
            ),
          );
        },
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CachedNetworkImage(
              imageUrl: getImageVAlidUrl(model.photo.toString()),
              imageBuilder: (context, imageProvider) => Container(
                height: MediaQuery.of(context).size.height * 0.08,
                width: MediaQuery.of(context).size.width * 0.18,
                decoration:
                    BoxDecoration(borderRadius: BorderRadius.circular(25)),
                child: Container(
                  // height: 80,width: 80,

                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: isDarkMode(context)
                        ? const Color(DarkContainerColor)
                        : Colors.white,
                    boxShadow: [
                      isDarkMode(context)
                          ? const BoxShadow()
                          : BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              blurRadius: 5,
                            ),
                    ],
                  ),

                  child: Stack(
                    children: [
                      // Background image
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                              image: imageProvider,
                              fit: BoxFit.cover,
                            )),
                      ),
                      // Title overlay at the bottom inside the card
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            borderRadius: const BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                            ),
                          ),
                          child: Text(
                            model.title.toString(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: "Poppinsr",
                              fontSize: 12,
                            ),
                          ).tr(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              memCacheHeight:
                  (MediaQuery.of(context).size.height * 0.11).toInt(),
              memCacheWidth: (MediaQuery.of(context).size.width * 0.23).toInt(),
              placeholder: (context, url) => ClipOval(
                child: Container(
                  // padding: EdgeInsets.only(top: 10),

                  decoration: BoxDecoration(
                    borderRadius:
                        const BorderRadius.all(Radius.circular(75 / 1)),
                  ),

                  width: 75,

                  height: 75,

                  child: Icon(
                    Icons.fastfood,
                    color: Color(COLOR_PRIMARY),
                  ),
                ),
              ),
              errorWidget: (context, url, error) => ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.network(
                    AppGlobal.placeHolderImage!,
                    fit: BoxFit.cover,
                  )),
            ),
            // displayCircleImage(model.photo, 90, false),
          ],
        ),
      ),
    );
  }

  // Helper function to get stable random product image for vendor
  String getStableRandomProductImage(VendorModel vendor) {
    // Filter products by vendor ID
    List<ProductModel> vendorProducts =
        allProducts.where((product) => product.vendorID == vendor.id).toList();

    if (vendorProducts.isEmpty) {
      // Fallback to vendor photo if no products found
      return getImageVAlidUrl(vendor.photo);
    }

    // Use vendor title hash to get stable random index
    int index = vendor.title.hashCode.abs() % vendorProducts.length;
    return getImageVAlidUrl(vendorProducts[index].photo);
  }

  @override
  void dispose() {
    fireStoreUtils.closeVendorStream();
    fireStoreUtils.closeNewArrivalStream();
    orderAgainStreamSubscription?.cancel();

    super.dispose();
  }

  openCouponCode(
    BuildContext context,
    OfferModel offerModel,
  ) {
    return Container(
      height: 250,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
              margin: const EdgeInsets.only(
                left: 40,
                right: 40,
              ),
              padding: const EdgeInsets.only(
                left: 50,
                right: 50,
              ),
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/images/offer_code_bg.png"))),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text(
                  offerModel.offerCode!,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.9),
                ),
              )),
          GestureDetector(
            onTap: () {
              FlutterClipboard.copy(offerModel.offerCode!).then((value) {
                final SnackBar snackBar = SnackBar(
                    content: Text(
                      "Coupon code copied".tr(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white),
                    ),
                    backgroundColor: const Color.fromARGB(250, 190, 187, 146));

                ScaffoldMessenger.of(context).showSnackBar(snackBar);

                return Navigator.pop(context);
              });
            },
            child: Container(
              margin: const EdgeInsets.only(top: 30, bottom: 30),
              child: Text(
                "COPY CODE".tr(),
                style: TextStyle(
                    color: Color(COLOR_PRIMARY),
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.1),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(bottom: 30),
            child: RichText(
              text: TextSpan(
                text: "Use code".tr(),
                style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.grey,
                    fontWeight: FontWeight.w700),
                children: <TextSpan>[
                  TextSpan(
                    text: offerModel.offerCode,
                    style: TextStyle(
                        color: Color(COLOR_PRIMARY),
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.1),
                  ),
                  TextSpan(
                    text: " & get".tr() +
                        " ${offerModel.discountType == "Fix Price" ? "${currencyModel!.symbol}" : ""}${offerModel.discount} ${offerModel.discountType == "Percentage" ? "% off".tr() : "off".tr()} ",
                    style: const TextStyle(
                        fontSize: 16.0,
                        color: Colors.grey,
                        fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildNewArrivalItem(VendorModel vendorModel) {
    bool restaurantIsOpen = isRestaurantOpen(vendorModel);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: GestureDetector(
        onTap: () => push(
          context,
          NewVendorProductsScreen(vendorModel: vendorModel),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.75,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isDarkMode(context)
                  ? [
                      const Color(0xFF2C2C2C),
                      const Color(0xFF1A1A1A),
                    ]
                  : [
                      Colors.white,
                      const Color(0xFFF8F9FA),
                    ],
            ),
            boxShadow: [
              BoxShadow(
                color: isDarkMode(context)
                    ? Colors.black.withOpacity(0.3)
                    : Colors.grey.withOpacity(0.15),
                blurRadius: 20,
                offset: const Offset(0, 8),
                spreadRadius: 0,
              ),
              BoxShadow(
                color: isDarkMode(context)
                    ? Colors.black.withOpacity(0.1)
                    : Colors.grey.withOpacity(0.05),
                blurRadius: 40,
                offset: const Offset(0, 16),
                spreadRadius: 0,
              ),
            ],
          ),
          child: Stack(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Image Container with overlay
                  Expanded(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(24),
                            topRight: Radius.circular(24),
                          ),
                          child: CachedNetworkImage(
                            imageUrl: getImageVAlidUrl(vendorModel.photo),
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.cover,
                            placeholder: (context, url) => Container(
                              decoration: BoxDecoration(
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(24),
                                  topRight: Radius.circular(24),
                                ),
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(COLOR_PRIMARY).withOpacity(0.1),
                                    Color(COLOR_PRIMARY).withOpacity(0.05),
                                  ],
                                ),
                              ),
                              child: Center(
                                child: CircularProgressIndicator.adaptive(
                                  valueColor: AlwaysStoppedAnimation(
                                      Color(COLOR_PRIMARY)),
                                ),
                              ),
                            ),
                            errorWidget: (context, url, error) => Container(
                              decoration: BoxDecoration(
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(24),
                                  topRight: Radius.circular(24),
                                ),
                                color: Colors.grey.shade200,
                              ),
                              child: Icon(
                                Icons.restaurant,
                                size: 50,
                                color: Colors.grey.shade400,
                              ),
                            ),
                          ),
                        ),
                        // Gradient overlay for better text readability
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(24),
                                topRight: Radius.circular(24),
                              ),
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.transparent,
                                  Colors.black.withOpacity(0.3),
                                ],
                              ),
                            ),
                          ),
                        ),
                        // Rating badge
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.95),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.star,
                                  size: 16,
                                  color: Color(COLOR_PRIMARY),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  vendorModel.reviewsCount != 0
                                      ? '${(vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1)}'
                                      : '0.0',
                                  style: TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: isDarkMode(context)
                                        ? Colors.black
                                        : Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // "NEW" badge
                        Positioned(
                          top: 12,
                          left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(COLOR_PRIMARY),
                                  Color(COLOR_PRIMARY).withOpacity(0.8),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(COLOR_PRIMARY).withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Text(
                              'NEW',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Content section
                  Container(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Restaurant name
                        Text(
                          vendorModel.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: "Poppinsm",
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.2,
                            color: isDarkMode(context)
                                ? Colors.white
                                : Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        // Location row
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Color(COLOR_PRIMARY).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.location_on,
                                size: 16,
                                color: Color(COLOR_PRIMARY),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                vendorModel.location,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: "Poppinsm",
                                  fontSize: 14,
                                  color: isDarkMode(context)
                                      ? Colors.white70
                                      : Colors.grey.shade600,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // Bottom row with reviews and distance
                        Row(
                          children: [
                            // Reviews count
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: isDarkMode(context)
                                    ? Colors.white.withOpacity(0.1)
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '${vendorModel.reviewsCount} reviews',
                                style: TextStyle(
                                  fontFamily: "Poppinsm",
                                  fontSize: 12,
                                  color: isDarkMode(context)
                                      ? Colors.white70
                                      : Colors.grey.shade600,
                                ),
                              ),
                            ),
                            const Spacer(),
                            // Distance indicator
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Color(COLOR_PRIMARY).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.directions_walk,
                                    size: 14,
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    'Nearby',
                                    style: TextStyle(
                                      fontFamily: "Poppinsm",
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Color(COLOR_PRIMARY),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              // Overlay for closed restaurants
              if (!restaurantIsOpen)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      color: Colors.black.withOpacity(0.6),
                    ),
                    child: Center(
                      child: Text(
                        'Temporarily Closed'.tr(),
                        style: TextStyle(
                          fontFamily: "Poppinsm",
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildPopularsItem(VendorModel vendorModel) {
    if (!mounted) {
      return Container();
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: GestureDetector(
        onTap: () => push(
          context,
          NewVendorProductsScreen(vendorModel: vendorModel),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.75,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isDarkMode(context)
                  ? [
                      const Color(0xFF2C2C2C),
                      const Color(0xFF1A1A1A),
                    ]
                  : [
                      Colors.white,
                      const Color(0xFFF8F9FA),
                    ],
            ),
            boxShadow: [
              BoxShadow(
                color: isDarkMode(context)
                    ? Colors.black.withOpacity(0.3)
                    : Colors.grey.withOpacity(0.15),
                blurRadius: 20,
                offset: const Offset(0, 8),
                spreadRadius: 0,
              ),
              BoxShadow(
                color: isDarkMode(context)
                    ? Colors.black.withOpacity(0.1)
                    : Colors.grey.withOpacity(0.05),
                blurRadius: 40,
                offset: const Offset(0, 16),
                spreadRadius: 0,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Image Container with overlay
              Expanded(
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24),
                      ),
                      child: CachedNetworkImage(
                        imageUrl: getImageVAlidUrl(vendorModel.photo),
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(24),
                              topRight: Radius.circular(24),
                            ),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(COLOR_PRIMARY).withOpacity(0.1),
                                Color(COLOR_PRIMARY).withOpacity(0.05),
                              ],
                            ),
                          ),
                          child: Center(
                            child: CircularProgressIndicator.adaptive(
                              valueColor:
                                  AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                            ),
                          ),
                        ),
                        errorWidget: (context, url, error) => Container(
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(24),
                              topRight: Radius.circular(24),
                            ),
                            color: Colors.grey.shade200,
                          ),
                          child: Icon(
                            Icons.restaurant,
                            size: 50,
                            color: Colors.grey.shade400,
                          ),
                        ),
                      ),
                    ),
                    // Gradient overlay for better text readability
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(24),
                            topRight: Radius.circular(24),
                          ),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.3),
                            ],
                          ),
                        ),
                      ),
                    ),
                    // Rating badge
                    Positioned(
                      top: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.95),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.star,
                              size: 16,
                              color: Color(COLOR_PRIMARY),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              vendorModel.reviewsCount != 0
                                  ? '${(vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1)}'
                                  : '0.0',
                              style: TextStyle(
                                fontFamily: "Poppinsm",
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: isDarkMode(context)
                                    ? Colors.black
                                    : Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    // "POPULAR" badge
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.orange.shade400,
                              Colors.orange.shade600,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.orange.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.trending_up,
                              size: 12,
                              color: Colors.white,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'POPULAR',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Content section
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Restaurant name
                    Text(
                      vendorModel.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: "Poppinsm",
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.2,
                        color:
                            isDarkMode(context) ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Location row
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: Color(COLOR_PRIMARY).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.location_on,
                            size: 16,
                            color: Color(COLOR_PRIMARY),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            vendorModel.location,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: "Poppinsm",
                              fontSize: 14,
                              color: isDarkMode(context)
                                  ? Colors.white70
                                  : Colors.grey.shade600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Bottom row with reviews and popularity indicator
                    Row(
                      children: [
                        // Reviews count
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: isDarkMode(context)
                                ? Colors.white.withOpacity(0.1)
                                : Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            '${vendorModel.reviewsCount} reviews',
                            style: TextStyle(
                              fontFamily: "Poppinsm",
                              fontSize: 12,
                              color: isDarkMode(context)
                                  ? Colors.white70
                                  : Colors.grey.shade600,
                            ),
                          ),
                        ),
                        const Spacer(),
                        // Popularity indicator
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.orange.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.local_fire_department,
                                size: 14,
                                color: Colors.orange.shade600,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Trending',
                                style: TextStyle(
                                  fontFamily: "Poppinsm",
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.orange.shade600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCouponsForYouItem(
      BuildContext context1, VendorModel? vendorModel, OfferModel offerModel) {
    return vendorModel == null
        ? Container()
        : Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: GestureDetector(
              onTap: () {
                if (vendorModel.id.toString() ==
                    offerModel.restaurantId.toString()) {
                  push(
                    context,
                    NewVendorProductsScreen(vendorModel: vendorModel),
                  );
                } else {
                  showModalBottomSheet(
                    isScrollControlled: true,
                    isDismissible: true,
                    context: context,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    backgroundColor: Colors.transparent,
                    enableDrag: true,
                    builder: (context) => openCouponCode(context, offerModel),
                  );
                }
              },
              child: Container(
                width: MediaQuery.of(context).size.width * 0.75,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: isDarkMode(context)
                        ? [
                            const Color(0xFF2C2C2C),
                            const Color(0xFF1A1A1A),
                          ]
                        : [
                            Colors.white,
                            const Color(0xFFF8F9FA),
                          ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isDarkMode(context)
                          ? Colors.black.withOpacity(0.3)
                          : Colors.grey.withOpacity(0.15),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                      spreadRadius: 0,
                    ),
                    BoxShadow(
                      color: isDarkMode(context)
                          ? Colors.black.withOpacity(0.1)
                          : Colors.grey.withOpacity(0.05),
                      blurRadius: 40,
                      offset: const Offset(0, 16),
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Image Container with overlay
                    Expanded(
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(24),
                              topRight: Radius.circular(24),
                            ),
                            child: CachedNetworkImage(
                              imageUrl:
                                  getImageVAlidUrl(offerModel.imageOffer!),
                              width: double.infinity,
                              height: double.infinity,
                              fit: BoxFit.cover,
                              placeholder: (context, url) => Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(24),
                                    topRight: Radius.circular(24),
                                  ),
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Color(COLOR_PRIMARY).withOpacity(0.1),
                                      Color(COLOR_PRIMARY).withOpacity(0.05),
                                    ],
                                  ),
                                ),
                                child: Center(
                                  child: CircularProgressIndicator.adaptive(
                                    valueColor: AlwaysStoppedAnimation(
                                        Color(COLOR_PRIMARY)),
                                  ),
                                ),
                              ),
                              errorWidget: (context, url, error) => Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(24),
                                    topRight: Radius.circular(24),
                                  ),
                                  color: Colors.grey.shade200,
                                ),
                                child: Icon(
                                  Icons.local_offer,
                                  size: 50,
                                  color: Colors.grey.shade400,
                                ),
                              ),
                            ),
                          ),
                          // Gradient overlay for better text readability
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(24),
                                  topRight: Radius.circular(24),
                                ),
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(0.4),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          // Discount badge
                          Positioned(
                            top: 12,
                            right: 12,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.red.shade400,
                                    Colors.red.shade600,
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.red.withOpacity(0.3),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                "${offerModel.discountType == "Fix Price" ? "${currencyModel!.symbol}" : ""}${offerModel.discount}${offerModel.discountType == "Percentage" ? "% OFF" : " OFF"}",
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ),
                          // "OFFER" badge
                          Positioned(
                            top: 12,
                            left: 12,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.purple.shade400,
                                    Colors.purple.shade600,
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.purple.withOpacity(0.3),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.local_offer,
                                    size: 12,
                                    color: Colors.white,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    'OFFER',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Content section
                    Container(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Restaurant name or offer title
                          vendorModel.id.toString() ==
                                  offerModel.restaurantId.toString()
                              ? Text(
                                  vendorModel.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.2,
                                    color: isDarkMode(context)
                                        ? Colors.white
                                        : Colors.black87,
                                  ),
                                )
                              : Text(
                                  "Foodie's Offer",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.2,
                                    color: isDarkMode(context)
                                        ? Colors.white
                                        : Colors.black87,
                                  ),
                                ),
                          const SizedBox(height: 8),
                          // Location or offer description
                          vendorModel.id.toString() ==
                                  offerModel.restaurantId.toString()
                              ? Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: Color(COLOR_PRIMARY)
                                            .withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Icon(
                                        Icons.location_on,
                                        size: 16,
                                        color: Color(COLOR_PRIMARY),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        vendorModel.location,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontFamily: "Poppinsm",
                                          fontSize: 14,
                                          color: isDarkMode(context)
                                              ? Colors.white70
                                              : Colors.grey.shade600,
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : Text(
                                  "Apply Offer",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: "Poppinsm",
                                    fontSize: 14,
                                    color: isDarkMode(context)
                                        ? Colors.white70
                                        : Colors.grey.shade600,
                                  ),
                                ),
                          const SizedBox(height: 12),
                          // Bottom row with coupon code and additional info
                          Row(
                            children: [
                              // Coupon code
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {
                                    FlutterClipboard.copy(offerModel.offerCode!)
                                        .then((value) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            "Coupon code copied!",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          backgroundColor: Color(COLOR_PRIMARY),
                                          duration: Duration(seconds: 2),
                                        ),
                                      );
                                    });
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 8),
                                    decoration: BoxDecoration(
                                      color:
                                          Color(COLOR_PRIMARY).withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: Color(COLOR_PRIMARY)
                                            .withOpacity(0.3),
                                        width: 1,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          Icons.copy,
                                          size: 16,
                                          color: Color(COLOR_PRIMARY),
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          offerModel.offerCode!,
                                          style: TextStyle(
                                            fontFamily: "Poppinsm",
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            color: Color(COLOR_PRIMARY),
                                            letterSpacing: 0.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              // Additional info (rating for restaurant offers)
                              vendorModel.id.toString() ==
                                      offerModel.restaurantId.toString()
                                  ? Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: isDarkMode(context)
                                            ? Colors.white.withOpacity(0.1)
                                            : Colors.grey.shade100,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            Icons.star,
                                            size: 16,
                                            color: Color(COLOR_PRIMARY),
                                          ),
                                          const SizedBox(width: 4),
                                          Text(
                                            vendorModel.reviewsCount != 0
                                                ? '${(vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1)}'
                                                : '0.0',
                                            style: TextStyle(
                                              fontFamily: "Poppinsm",
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: isDarkMode(context)
                                                  ? Colors.white70
                                                  : Colors.grey.shade600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.purple.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            Icons.flash_on,
                                            size: 14,
                                            color: Colors.purple.shade600,
                                          ),
                                          const SizedBox(width: 4),
                                          Text(
                                            'Limited Time',
                                            style: TextStyle(
                                              fontFamily: "Poppinsm",
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.purple.shade600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }

  Widget buildVendorItem(VendorModel vendorModel) {
    bool restaurantIsOpen = isRestaurantOpen(vendorModel);

    return GestureDetector(
      onTap: () => push(
        context,
        NewVendorProductsScreen(vendorModel: vendorModel),
      ),
      child: Container(
        height: 120,
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: isDarkMode(context)
                  ? const Color(DarkContainerBorderColor)
                  : Colors.grey.shade100,
              width: 1),
          color: isDarkMode(context)
              ? const Color(DarkContainerColor)
              : Colors.white,
          boxShadow: [
            isDarkMode(context)
                ? const BoxShadow()
                : BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 5,
                  ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Expanded(
                    child: CachedNetworkImage(
                  imageUrl: getImageVAlidUrl(vendorModel.photo),
                  memCacheWidth: (MediaQuery.of(context).size.width).toInt(),
                  memCacheHeight: 120,
                  imageBuilder: (context, imageProvider) => Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image: imageProvider, fit: BoxFit.cover),
                    ),
                  ),
                  placeholder: (context, url) => Center(
                      child: CircularProgressIndicator.adaptive(
                    valueColor: AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
                  )),
                  errorWidget: (context, url, error) => ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(AppGlobal.placeHolderImage!)),
                  fit: BoxFit.cover,
                )),
                const SizedBox(height: 8),
                ListTile(
                  title: Text(vendorModel.title,
                      maxLines: 1,
                      style: const TextStyle(
                        fontFamily: "Poppinsm",
                        letterSpacing: 0.5,
                        color: Color(0xff000000),
                      )).tr(),
                  subtitle: Row(
                    children: [
                      ImageIcon(
                        AssetImage('assets/images/location3x.png'),
                        size: 15,
                        color: Color(COLOR_PRIMARY),
                      ),
                      SizedBox(
                        width: 200,
                        child: Text(vendorModel.location,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: "Poppinsm",
                              letterSpacing: 0.5,
                              color: Color(0xff555353),
                            )),
                      ),
                    ],
                  ),
                  trailing: Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.star,
                              size: 20,
                              color: Color(COLOR_PRIMARY),
                            ),
                            const SizedBox(width: 3),
                            Text(
                                vendorModel.reviewsCount != 0
                                    ? '${(vendorModel.reviewsSum / vendorModel.reviewsCount).toStringAsFixed(1)}'
                                    : 0.toString(),
                                style: const TextStyle(
                                  fontFamily: "Poppinsm",
                                  letterSpacing: 0.5,
                                  color: Color(0xff000000),
                                )),
                            const SizedBox(width: 3),
                            Text(
                                '(${vendorModel.reviewsCount.toStringAsFixed(1)})',
                                style: const TextStyle(
                                  fontFamily: "Poppinsm",
                                  letterSpacing: 0.5,
                                  color: Color(0xff666666),
                                )),
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
            // Overlay for closed restaurants
            if (!restaurantIsOpen)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.black.withOpacity(0.6),
                  ),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'Temporarily Closed'.tr(),
                        style: TextStyle(
                          fontFamily: "Poppinsm",
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.red.shade700,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  bool isRestaurantOpen(VendorModel vendorModel) {
    final now = DateTime.now();
    var day = DateFormat('EEEE', 'en_US').format(now);
    var date = DateFormat('dd-MM-yyyy').format(now);

    bool isOpen = false;

    for (var workingHour in vendorModel.workingHours) {
      if (day == workingHour.day.toString()) {
        if (workingHour.timeslot != null && workingHour.timeslot!.isNotEmpty) {
          for (var timeSlot in workingHour.timeslot!) {
            var start = DateFormat("dd-MM-yyyy HH:mm")
                .parse(date + " " + timeSlot.from.toString());
            var end = DateFormat("dd-MM-yyyy HH:mm")
                .parse(date + " " + timeSlot.to.toString());

            if (isCurrentDateInRange(start, end)) {
              isOpen = true;
              break;
            }
          }
        }
        if (isOpen) break;
      }
    }

    return isOpen && vendorModel.reststatus;
  }

  bool isCurrentDateInRange(DateTime startDate, DateTime endDate) {
    final currentDate = DateTime.now();
    return currentDate.isAfter(startDate) && currentDate.isBefore(endDate);
  }

  Future<void> saveFoodTypeValue() async {
    SharedPreferences sp = await SharedPreferences.getInstance();

    sp.setString('foodType', selctedOrderTypeValue!);
  }

  getFoodType() async {
    SharedPreferences sp = await SharedPreferences.getInstance();

    if (mounted) {
      setState(() {
        selctedOrderTypeValue =
            sp.getString("foodType") == "" || sp.getString("foodType") == null
                ? "Delivery"
                : sp.getString("foodType");
      });
    }

    if (selctedOrderTypeValue == "Takeaway") {
      productsFuture = fireStoreUtils.getAllTakeAWayProducts();
    } else {
      productsFuture = fireStoreUtils.getAllDelevryProducts();
    }
  }

  bool isLoading = true;

  getLocationData() async {
    try {
      await getData();
    } catch (e) {
      getPermission();
    }
  }

  getPermission() async {
    setState(() {
      isLoading = false;
    });

    PermissionStatus _permissionGranted = await location.hasPermission();

    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();

      if (_permissionGranted != PermissionStatus.granted) {
        await getData();
      }
    }

    setState(() {
      isLoading = false;
    });
  }

  Future<void> getData() async {
    getFoodType();

    lstNearByFood.clear();

    fireStoreUtils.getRestaurantNearBy().whenComplete(() async {
      lstAllRestaurant = fireStoreUtils.getAllRestaurants().asBroadcastStream();

      if (MyAppState.currentUser != null) {
        lstFavourites = fireStoreUtils
            .getFavouriteRestaurant(MyAppState.currentUser!.userID);

        lstFavourites.then((event) {
          lstFav.clear();

          for (int a = 0; a < event.length; a++) {
            lstFav.add(event[a].restaurantId!);
          }
        });

        name = toBeginningOfSentenceCase(widget.user!.firstName);
      }

      lstAllRestaurant!.listen((event) {
        vendors.clear();

        vendors.addAll(event);

        allstoreList.clear();

        allstoreList.addAll(event);

        productsFuture.then((value) {
          for (int a = 0; a < event.length; a++) {
            for (int d = 0; d < (value.length > 20 ? 20 : value.length); d++) {
              if (event[a].id == value[d].vendorID &&
                  !lstNearByFood.contains(value[d])) {
                lstNearByFood.add(value[d]);
              }
            }
          }
        });

        popularRestaurantLst.addAll(event);

        List<VendorModel> temp5 = popularRestaurantLst
            .where((element) =>
                num.parse(
                    (element.reviewsSum / element.reviewsCount).toString()) ==
                5)
            .toList();

        List<VendorModel> temp5_ = popularRestaurantLst
            .where((element) =>
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) >
                    4 &&
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) <
                    5)
            .toList();

        List<VendorModel> temp4 = popularRestaurantLst
            .where((element) =>
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) >
                    3 &&
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) <
                    4)
            .toList();

        List<VendorModel> temp3 = popularRestaurantLst
            .where((element) =>
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) >
                    2 &&
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) <
                    3)
            .toList();

        List<VendorModel> temp2 = popularRestaurantLst
            .where((element) =>
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) >
                    1 &&
                num.parse((element.reviewsSum / element.reviewsCount)
                        .toString()) <
                    2)
            .toList();

        List<VendorModel> temp1 = popularRestaurantLst
            .where((element) =>
                num.parse(
                    (element.reviewsSum / element.reviewsCount).toString()) ==
                1)
            .toList();

        List<VendorModel> temp0 = popularRestaurantLst
            .where((element) =>
                num.parse(
                    (element.reviewsSum / element.reviewsCount).toString()) ==
                0)
            .toList();

        List<VendorModel> temp0_ = popularRestaurantLst
            .where((element) =>
                element.reviewsSum == 0 && element.reviewsCount == 0)
            .toList();

        popularRestaurantLst.clear();

        popularRestaurantLst.addAll(temp5);

        popularRestaurantLst.addAll(temp5_);

        popularRestaurantLst.addAll(temp4);

        popularRestaurantLst.addAll(temp3);

        popularRestaurantLst.addAll(temp2);

        popularRestaurantLst.addAll(temp1);

        popularRestaurantLst.addAll(temp0);

        popularRestaurantLst.addAll(temp0_);

        FireStoreUtils().getPublicCoupons().then((value) {
          offersList.clear();

          offerVendorList.clear();

          value.forEach((element1) {
            event.forEach((element) {
              if (element1.restaurantId == element.id &&
                  element1.expireOfferDate!.toDate().isAfter(DateTime.now())) {
                offersList.add(element1);

                offerVendorList.add(element);
              }
            });
          });

          if (mounted) {
            setState(() {});
          }
        });

        FireStoreUtils().getStory().then((value) {
          storyList.clear();

          value.forEach((element1) {
            vendors.forEach((element) {
              if (element1.vendorID == element.id) {
                storyList.add(element1);
              }
            });
          });

          if (mounted) {
            setState(() {});
          }
        });
      });

      setState(() {});
    });

    setState(() {
      isLoading = false;
    });
  }

  List<StoryModel> storyList = [];

  void checkPermission(Function() onTap) async {
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      SnackBar snack = SnackBar(
        content: const Text(
          'You have to allow location permission to use your location',
          style: TextStyle(color: Colors.white),
        ).tr(),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.black,
      );

      ScaffoldMessenger.of(context).showSnackBar(snack);
    } else if (permission == LocationPermission.deniedForever) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return PermissionDialog();
        },
      );
    } else {
      onTap();
    }
  }
}

// ignore: camel_case_types

class buildTitleRow extends StatelessWidget {
  final String titleValue;
  final Function? onClick;
  final bool? isViewAll;
  final IconData? titleIcon;

  const buildTitleRow({
    Key? key,
    required this.titleValue,
    this.onClick,
    this.isViewAll = false,
    this.titleIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: isDarkMode(context)
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF2D2D2D),
                  const Color(0xFF1A1A1A),
                ],
              )
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFFFFFFFF),
                  const Color(0xFFF8F9FA),
                ],
              ),
      ),
      child: Align(
        alignment: Alignment.topLeft,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  if (titleIcon != null) ...[
                    Icon(
                      titleIcon,
                      color: isDarkMode(context)
                          ? Colors.white
                          : const Color(0xFF000000),
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                  ],
                  Text(titleValue.tr(),
                      style: TextStyle(
                          color: isDarkMode(context)
                              ? Colors.white
                              : const Color(0xFF000000),
                          fontFamily: "Poppinsm",
                          fontSize: 18)),
                ],
              ),
              isViewAll!
                  ? Container()
                  : GestureDetector(
                      onTap: () {
                        onClick!.call();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode(context)
                              ? Colors.white.withOpacity(0.1)
                              : Colors.black.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color:
                              isDarkMode(context) ? Colors.white : Colors.black,
                          size: 16,
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable

class MoreStories extends StatefulWidget {
  List<StoryModel> storyList = [];

  int index;

  MoreStories({Key? key, required this.index, required this.storyList})
      : super(key: key);

  @override
  _MoreStoriesState createState() => _MoreStoriesState();
}

class _MoreStoriesState extends State<MoreStories> {
  final storyController = StoryController();

  @override
  void dispose() {
    storyController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: [
        StoryView(
            storyItems: List.generate(
              widget.storyList[widget.index].videoUrl.length,
              (i) {
                return StoryItem.pageVideo(
                  widget.storyList[widget.index].videoUrl[i],
                  controller: storyController,
                );
              },
            ).toList(),
            onStoryShow: (story, index) {
              debugPrint("Showing a story");
            },
            onComplete: () {
              debugPrint("--------->");

              debugPrint(widget.storyList.length.toString());

              debugPrint(widget.index.toString());

              if (widget.storyList.length - 1 != widget.index) {
                // Navigator.pop(context);

                // Navigator.of(context).push(MaterialPageRoute(

                //     builder: (context) => MoreStories(

                //       storyList: widget.storyList,

                //       index: widget.index + 1,

                //     )));

                setState(() {
                  widget.index = widget.index + 1;
                });
              } else {
                Navigator.pop(context);
              }
            },
            progressPosition: ProgressPosition.top,
            repeat: true,
            controller: storyController,
            onVerticalSwipeComplete: (direction) {
              if (direction == Direction.down) {
                Navigator.pop(context);
              }
            }),
        FutureBuilder(
          future: FireStoreUtils().getVendorByVendorID(
              widget.storyList[widget.index].vendorID.toString()),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: Container());
            } else {
              if (snapshot.hasError) {
                return Center(
                    child: Text("Error".tr() + ": ${snapshot.error}"));
              } else {
                VendorModel? vendorModel = snapshot.data;

                double distanceInMeters = Geolocator.distanceBetween(
                    vendorModel!.latitude,
                    vendorModel.longitude,
                    MyAppState.selectedPosotion.location!.latitude,
                    MyAppState.selectedPosotion.location!.longitude);

                double kilometer = distanceInMeters / 1000;

                return Positioned(
                  top: 55,
                  child: InkWell(
                    onTap: () {
                      push(
                        context,
                        NewVendorProductsScreen(vendorModel: vendorModel),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: CachedNetworkImage(
                              imageUrl: vendorModel.photo,
                              height: 50,
                              width: 50,
                              imageBuilder: (context, imageProvider) =>
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  image: DecorationImage(
                                      image: imageProvider, fit: BoxFit.cover),
                                ),
                              ),
                              placeholder: (context, url) => Center(
                                  child: CircularProgressIndicator.adaptive(
                                valueColor: AlwaysStoppedAnimation(
                                    Color(COLOR_PRIMARY)),
                              )),
                              errorWidget: (context, url, error) => ClipRRect(
                                  borderRadius: BorderRadius.circular(30),
                                  child: Image.network(
                                    AppGlobal.placeHolderImage!,
                                    fit: BoxFit.cover,
                                    width: MediaQuery.of(context).size.width,
                                    height: MediaQuery.of(context).size.height,
                                  )),
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(vendorModel.title.toString(),
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 2),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                              vendorModel.reviewsCount != 0
                                                  ? (vendorModel.reviewsSum /
                                                          vendorModel
                                                              .reviewsCount)
                                                      .toStringAsFixed(1)
                                                  : 0.toString(),
                                              style: const TextStyle(
                                                fontFamily: "Poppinsm",
                                                letterSpacing: 0.5,
                                                fontSize: 12,
                                                color: Colors.white,
                                              )),
                                          const SizedBox(width: 3),
                                          const Icon(
                                            Icons.star,
                                            size: 16,
                                            color: Colors.white,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Icon(
                                    Icons.location_pin,
                                    size: 16,
                                    color: Color(COLOR_PRIMARY),
                                  ),
                                  SizedBox(
                                    width: 3,
                                  ),
                                  Text(
                                      "${kilometer.toDouble().toStringAsFixed(currencyModel!.decimal)} KM",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: "Poppinsr")),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Container(
                                    height: 15,
                                    child: VerticalDivider(
                                      color: Colors.white,
                                      thickness: 2,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                      DateTime.now()
                                                  .difference(widget
                                                      .storyList[widget.index]
                                                      .createdAt!
                                                      .toDate())
                                                  .inDays ==
                                              0
                                          ? 'Today'.tr()
                                          : "${DateTime.now().difference(widget.storyList[widget.index].createdAt!.toDate()).inDays.toString()} d",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: "Poppinsr")),
                                ],
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                );
              }
            }
          },
        )
      ],
    ));
  }
}
